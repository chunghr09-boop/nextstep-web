import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { JobSearchHero } from './components/JobSearchHero';
import { JobList } from './components/JobList';
import { JobDetailModal } from './components/JobDetailModal';
import { QuickApplyModal } from './components/QuickApplyModal';
import { ProfileManager } from './components/ProfileManager';
import { ApplicationTracker } from './components/ApplicationTracker';
import { SavedJobsView } from './components/SavedJobsView';
import { SalaryCalculatorView } from './components/SalaryCalculatorModal';
import { RecruiterPortal } from './components/RecruiterPortal';
import { RecruiterChatModal } from './components/RecruiterChatModal';
import { NextstepLogo } from './components/NextstepLogo';
import { QuickContactWidget } from './components/QuickContactWidget';
import { NEXTSTEP_COMPANY_INFO } from './data/companyInfo';
import { PhoneCall, Mail, MapPin } from 'lucide-react';

import { Job, FilterState, CandidateProfile, Application, RecruiterView, ChatMessage } from './types';
import { INITIAL_JOBS } from './data/mockJobs';
import { 
  INITIAL_PROFILE, 
  INITIAL_APPLICATIONS, 
  INITIAL_RECRUITER_VIEWS, 
  INITIAL_MESSAGES 
} from './data/initialProfile';

const STORAGE_KEYS = {
  PROFILE: 'jobsgo_candidate_profile_v1',
  APPLICATIONS: 'jobsgo_applications_v1',
  SAVED_JOBS: 'jobsgo_saved_jobs_v1',
  CUSTOM_JOBS: 'jobsgo_custom_jobs_v1',
  MESSAGES: 'jobsgo_chat_messages_v1'
};

export default function App() {
  // Navigation tab
  const [activeTab, setActiveTab] = useState<'jobs' | 'profile' | 'applications' | 'saved' | 'salary' | 'recruiter_portal'>('jobs');

  // Candidate Profile State with LocalStorage
  const [profile, setProfile] = useState<CandidateProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_PROFILE;
  });

  // Applications State with LocalStorage
  const [applications, setApplications] = useState<Application[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_APPLICATIONS;
  });

  // Saved Job IDs State with LocalStorage
  const [savedJobIds, setSavedJobIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SAVED_JOBS);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return ['job-1', 'job-5'];
  });

  // Jobs state (mock + custom recruiter jobs)
  const [jobs, setJobs] = useState<Job[]>(() => {
    const custom = localStorage.getItem(STORAGE_KEYS.CUSTOM_JOBS);
    if (custom) {
      try {
        const parsedCustom: Job[] = JSON.parse(custom);
        return [...parsedCustom, ...INITIAL_JOBS];
      } catch (e) {}
    }
    return INITIAL_JOBS;
  });

  // Recruiter views
  const [recruiterViews] = useState<RecruiterView[]>(INITIAL_RECRUITER_VIEWS);

  // Chat messages with LocalStorage
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_MESSAGES;
  });

  // Modals
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [applyJob, setApplyJob] = useState<Job | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatCompany, setChatCompany] = useState<string>('');

  // Search Filters
  const [filters, setFilters] = useState<FilterState>({
    keyword: '',
    city: 'Tất cả địa điểm',
    industry: 'Tất cả ngành nghề',
    salaryRange: 'Tất cả mức lương',
    experience: 'Tất cả kinh nghiệm',
    level: 'Tất cả cấp bậc',
    jobType: 'Tất cả hình thức',
    isUrgentOnly: false,
    isRemoteOnly: false,
    sortBy: 'relevant'
  });

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_JOBS, JSON.stringify(savedJobIds));
  }, [savedJobIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  }, [messages]);

  // Filter & Search Logic
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // Keyword filter
      if (filters.keyword.trim()) {
        const kw = filters.keyword.toLowerCase().trim();
        const inTitle = job.title.toLowerCase().includes(kw);
        const inCompany = job.company.toLowerCase().includes(kw);
        const inTags = job.tags.some(t => t.toLowerCase().includes(kw));
        const inSkills = job.requiredSkills.some(s => s.toLowerCase().includes(kw));
        if (!inTitle && !inCompany && !inTags && !inSkills) {
          return false;
        }
      }

      // City filter
      if (filters.city !== 'Tất cả địa điểm') {
        if (filters.city === 'Toàn quốc') {
          // Allow all
        } else if (job.city !== filters.city && job.location !== filters.city) {
          return false;
        }
      }

      // Industry filter
      if (filters.industry !== 'Tất cả ngành nghề') {
        if (job.industry !== filters.industry) {
          return false;
        }
      }

      // Experience filter
      if (filters.experience !== 'Tất cả kinh nghiệm') {
        if (job.experience !== filters.experience) {
          return false;
        }
      }

      // Level filter
      if (filters.level !== 'Tất cả cấp bậc') {
        if (job.level !== filters.level) {
          return false;
        }
      }

      // Job Type filter
      if (filters.jobType !== 'Tất cả hình thức') {
        if (job.jobType !== filters.jobType) {
          return false;
        }
      }

      // Urgent only
      if (filters.isUrgentOnly && !job.isUrgent) {
        return false;
      }

      // Remote only
      if (filters.isRemoteOnly && job.jobType !== 'Remote' && !job.tags.includes('Remote')) {
        return false;
      }

      // Salary Range filter
      if (filters.salaryRange !== 'Tất cả mức lương') {
        const min = job.minSalary || 0;
        const max = job.maxSalary || min;

        if (filters.salaryRange === 'Dưới 10 triệu') {
          if (min > 10) return false;
        } else if (filters.salaryRange === '10 - 15 triệu') {
          if (max < 10 || min > 15) return false;
        } else if (filters.salaryRange === '15 - 25 triệu') {
          if (max < 15 || min > 25) return false;
        } else if (filters.salaryRange === '25 - 40 triệu') {
          if (max < 25 || min > 40) return false;
        } else if (filters.salaryRange === 'Trên 40 triệu') {
          if (max < 40) return false;
        } else if (filters.salaryRange === 'Thỏa thuận') {
          if (job.salaryType !== 'negotiable') return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'newest') {
        return b.id.localeCompare(a.id);
      } else if (filters.sortBy === 'salary_high') {
        const maxA = a.maxSalary || a.minSalary || 0;
        const maxB = b.maxSalary || b.minSalary || 0;
        return maxB - maxA;
      } else if (filters.sortBy === 'deadline') {
        return a.deadline.localeCompare(b.deadline);
      }
      // 'relevant' default: prioritize HOT and Urgent
      const weightA = (a.isHot ? 2 : 0) + (a.isUrgent ? 1 : 0);
      const weightB = (b.isHot ? 2 : 0) + (b.isUrgent ? 1 : 0);
      return weightB - weightA;
    });
  }, [jobs, filters]);

  // Saved Jobs list
  const savedJobs = useMemo(() => {
    return jobs.filter(j => savedJobIds.includes(j.id));
  }, [jobs, savedJobIds]);

  // Handlers
  const handleToggleSaveJob = (jobId: string) => {
    setSavedJobIds(prev => {
      if (prev.includes(jobId)) {
        return prev.filter(id => id !== jobId);
      } else {
        return [...prev, jobId];
      }
    });
  };

  const handleResetFilters = () => {
    setFilters({
      keyword: '',
      city: 'Tất cả địa điểm',
      industry: 'Tất cả ngành nghề',
      salaryRange: 'Tất cả mức lương',
      experience: 'Tất cả kinh nghiệm',
      level: 'Tất cả cấp bậc',
      jobType: 'Tất cả hình thức',
      isUrgentOnly: false,
      isRemoteOnly: false,
      sortBy: 'relevant'
    });
  };

  const handlePostNewJob = (newJob: Job) => {
    setJobs(prev => [newJob, ...prev]);
    const stored = localStorage.getItem(STORAGE_KEYS.CUSTOM_JOBS);
    let customList: Job[] = [];
    if (stored) {
      try { customList = JSON.parse(stored); } catch (e) {}
    }
    localStorage.setItem(STORAGE_KEYS.CUSTOM_JOBS, JSON.stringify([newJob, ...customList]));
  };

  const handleWithdrawApplication = (appId: string) => {
    setApplications(prev => prev.filter(a => a.id !== appId));
  };

  const handleOpenChatWithRecruiter = (company: string, jobTitle?: string) => {
    setChatCompany(company);
    setIsChatOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-slate-800">
      {/* Navbar Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        profile={profile}
        applicationsCount={applications.length}
        savedCount={savedJobIds.length}
        recruiterViews={recruiterViews}
        messages={messages}
        onOpenChat={() => { setChatCompany(''); setIsChatOpen(true); }}
      />

      {/* Main Content Areas */}
      <main className="flex-1">
        {/* VIEW 1: JOB SEARCH & LISTINGS */}
        {activeTab === 'jobs' && (
          <div>
            {/* Search Hero with Filter Bar */}
            <JobSearchHero
              filters={filters}
              setFilters={setFilters}
              totalJobsFound={filteredJobs.length}
              onResetFilters={handleResetFilters}
            />

            {/* Content Container */}
            <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Main Job Cards Feed */}
                <div className="lg:col-span-8">
                  <JobList
                    jobs={filteredJobs}
                    onSelectJob={(job) => setSelectedJob(job)}
                    onQuickApply={(job) => setApplyJob(job)}
                    savedJobIds={savedJobIds}
                    onToggleSaveJob={handleToggleSaveJob}
                    filters={filters}
                    setFilters={setFilters}
                    profile={profile}
                  />
                </div>

                {/* Right Sticky Sidebar: Profile Completeness Widget & Fast Tools */}
                <div className="lg:col-span-4 space-y-4">
                  {/* Candidate Quick Profile Card */}
                  <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={profile.avatar}
                        alt={profile.fullName}
                        className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500"
                      />
                      <div className="min-w-0 flex-1">
                        <h4 className="text-sm font-bold text-slate-900 truncate">
                          {profile.fullName}
                        </h4>
                        <p className="text-xs text-[#137E8F] font-semibold truncate">{profile.title}</p>
                      </div>
                    </div>

                    <div className="space-y-1.5 pt-1">
                      <div className="flex justify-between text-xs font-semibold">
                        <span className="text-slate-600">Độ mạnh hồ sơ:</span>
                        <span className="text-[#137E8F] font-bold">{profile.profileStrength}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-[#0D2B52] to-[#137E8F] h-full rounded-full transition-all"
                          style={{ width: `${profile.profileStrength}%` }}
                        ></div>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-500">
                      Hồ sơ của bạn đang ở trạng thái <strong>{profile.isLookingForJob ? 'Bật tìm việc' : 'Ẩn tìm việc'}</strong>. Nhà tuyển dụng có thể chủ động liên hệ.
                    </p>

                    <button
                      id="sidebar-edit-profile-btn"
                      onClick={() => setActiveTab('profile')}
                      className="w-full py-2.5 bg-teal-50 hover:bg-teal-100/80 text-[#0D2B52] font-bold rounded-xl text-xs transition-colors cursor-pointer border border-teal-200/60"
                    >
                      Cập nhật hồ sơ &amp; CV online
                    </button>
                  </div>

                  {/* Quick Application Status Box */}
                  <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-500">
                      Tiến độ ứng tuyển của bạn
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-center text-xs">
                      <div 
                        onClick={() => setActiveTab('applications')}
                        className="p-3 rounded-xl bg-teal-50/70 border border-teal-100 cursor-pointer hover:bg-teal-100/70 transition-colors"
                      >
                        <span className="text-xl font-black text-[#0D2B52]">{applications.length}</span>
                        <span className="block text-[11px] font-semibold text-slate-600 mt-0.5">Việc đã nộp</span>
                      </div>
                      <div 
                        onClick={() => setActiveTab('saved')}
                        className="p-3 rounded-xl bg-amber-50/70 border border-amber-100 cursor-pointer hover:bg-amber-100/70 transition-colors"
                      >
                        <span className="text-xl font-black text-amber-700">{savedJobIds.length}</span>
                        <span className="block text-[11px] font-semibold text-slate-600 mt-0.5">Việc đã lưu</span>
                      </div>
                    </div>
                  </div>

                  {/* Gross to Net Quick Banner */}
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0D2B52] via-[#103D69] to-[#137E8F] text-white shadow-md space-y-2.5">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded text-teal-200">
                      Tiện ích Nextstep
                    </span>
                    <h4 className="text-sm font-bold">Tra cứu mức lương &amp; Tính Net</h4>
                    <p className="text-xs text-teal-100/85 leading-relaxed">
                      Biết chính xác số tiền thực nhận sau bảo hiểm &amp; thuế thu nhập cá nhân trước khi đàm phán hợp đồng.
                    </p>
                    <button
                      onClick={() => setActiveTab('salary')}
                      className="w-full py-2 bg-white text-[#0D2B52] hover:bg-teal-50 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                    >
                      Mở công cụ tính lương
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: PROFILE MANAGEMENT (QUẢN LÝ HỒ SƠ CHI TIẾT ĐẦY ĐỦ NHẤT) */}
        {activeTab === 'profile' && (
          <ProfileManager
            profile={profile}
            onUpdateProfile={setProfile}
          />
        )}

        {/* VIEW 3: APPLICATION TRACKER */}
        {activeTab === 'applications' && (
          <ApplicationTracker
            applications={applications}
            onWithdrawApplication={handleWithdrawApplication}
            onOpenChatWithRecruiter={handleOpenChatWithRecruiter}
          />
        )}

        {/* VIEW 4: SAVED JOBS */}
        {activeTab === 'saved' && (
          <SavedJobsView
            savedJobs={savedJobs}
            onRemoveSaved={handleToggleSaveJob}
            onApply={(job) => setApplyJob(job)}
            onSelectJob={(job) => setSelectedJob(job)}
            onExploreMore={() => setActiveTab('jobs')}
          />
        )}

        {/* VIEW 5: SALARY CALCULATOR */}
        {activeTab === 'salary' && (
          <SalaryCalculatorView />
        )}

        {/* VIEW 6: RECRUITER PORTAL */}
        {activeTab === 'recruiter_portal' && (
          <RecruiterPortal
            onPostNewJob={handlePostNewJob}
            candidateProfile={profile}
            applications={applications}
            onBackToCandidateMode={() => setActiveTab('jobs')}
          />
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-gradient-to-b from-[#0F335A] via-[#0D2A4C] to-[#081B30] text-slate-200 text-xs border-t-4 border-[#137E8F] mt-16 shadow-2xl relative">
        <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
            <div className="space-y-4">
              {/* Brand Logo in crisp white pill to guarantee 100% brand visibility without blending into dark */}
              <div className="bg-white p-2 px-3.5 rounded-xl border border-teal-200/60 shadow-md inline-flex items-center">
                <NextstepLogo variant="full" size="md" showCompany={true} />
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">
                Hệ sinh thái tuyển dụng thông minh hàng đầu. Kết nối ứng viên tài năng với các vị trí tuyển dụng chiến lược trên toàn quốc.
              </p>
              
              <div className="space-y-2 text-xs">
                <a 
                  href={`tel:${NEXTSTEP_COMPANY_INFO.phoneClean}`}
                  className="flex items-center gap-2.5 p-2.5 px-3 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-400/40 rounded-xl text-emerald-300 hover:text-emerald-200 font-bold transition-all cursor-pointer shadow-xs"
                >
                  <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Hotline: {NEXTSTEP_COMPANY_INFO.phone}</span>
                </a>
                <a 
                  href={`mailto:${NEXTSTEP_COMPANY_INFO.email}`}
                  className="flex items-center gap-2.5 p-2.5 px-3 bg-teal-500/15 hover:bg-teal-500/25 border border-teal-400/40 rounded-xl text-teal-200 hover:text-teal-100 font-medium transition-all cursor-pointer truncate shadow-xs"
                >
                  <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                  <span className="truncate">Email: {NEXTSTEP_COMPANY_INFO.email}</span>
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm mb-3.5 pb-1.5 border-b border-white/10 flex items-center gap-2">
                <span className="w-1.5 h-3.5 bg-teal-400 rounded-full"></span>
                Dành cho Ứng viên
              </h4>
              <ul className="space-y-2.5 text-slate-300">
                <li><button onClick={() => setActiveTab('jobs')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Tìm việc làm mới nhất</button></li>
                <li><button onClick={() => setActiveTab('profile')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Tạo CV &amp; Quản lý hồ sơ số</button></li>
                <li><button onClick={() => setActiveTab('salary')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Tính lương Gross - Net</button></li>
                <li><button onClick={() => setActiveTab('applications')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Theo dõi việc đã nộp</button></li>
                <li><button onClick={() => setActiveTab('saved')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Việc làm đã lưu</button></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm mb-3.5 pb-1.5 border-b border-white/10 flex items-center gap-2">
                <span className="w-1.5 h-3.5 bg-emerald-400 rounded-full"></span>
                Dành cho Doanh nghiệp
              </h4>
              <ul className="space-y-2.5 text-slate-300">
                <li><button onClick={() => setActiveTab('recruiter_portal')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Cổng Nhà tuyển dụng</button></li>
                <li><button onClick={() => setActiveTab('recruiter_portal')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Đăng tin tuyển dụng nhanh</button></li>
                <li><button onClick={() => setActiveTab('recruiter_portal')} className="hover:text-teal-300 transition-colors cursor-pointer text-left">Duyệt hồ sơ ứng viên</button></li>
                <li><span className="hover:text-teal-300 transition-colors cursor-pointer">Giải pháp Talent Acquisition</span></li>
                <li><span className="hover:text-teal-300 transition-colors cursor-pointer">Chính sách bảo mật thông tin</span></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold text-sm mb-3.5 pb-1.5 border-b border-white/10 flex items-center gap-2">
                <span className="w-1.5 h-3.5 bg-amber-400 rounded-full"></span>
                Trụ sở &amp; Pháp nhân
              </h4>
              <div className="space-y-3 text-xs leading-relaxed">
                <p className="text-white font-bold text-sm">
                  {NEXTSTEP_COMPANY_INFO.companyName}
                </p>
                <p className="flex items-start gap-2 text-slate-200">
                  <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong className="text-white">Địa chỉ:</strong> {NEXTSTEP_COMPANY_INFO.address}</span>
                </p>
                <p className="text-slate-300">
                  <strong className="text-white">Giờ làm việc:</strong> Thứ Hai – Thứ Sáu (8:00 – 17:30), Thứ Bảy (8:00 – 12:00)
                </p>
                <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                  <span>© 2026 {NEXTSTEP_COMPANY_INFO.companyName}</span>
                  <span className="text-emerald-400 font-semibold">• All Rights Reserved</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* FLOATING QUICK CONTACT WIDGET */}
      <QuickContactWidget onOpenRecruiterChat={() => handleOpenChatWithRecruiter(NEXTSTEP_COMPANY_INFO.companyName)} />

      {/* MODAL 1: JOB DETAIL MODAL */}
      {selectedJob && (
        <JobDetailModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
          onApply={(job) => {
            setSelectedJob(null);
            setApplyJob(job);
          }}
          isSaved={savedJobIds.includes(selectedJob.id)}
          onToggleSave={handleToggleSaveJob}
          profile={profile}
        />
      )}

      {/* MODAL 2: QUICK APPLY MODAL */}
      {applyJob && (
        <QuickApplyModal
          job={applyJob}
          profile={profile}
          onClose={() => setApplyJob(null)}
          onSubmitApplication={(newApplication) => {
            setApplications(prev => [newApplication, ...prev]);
          }}
        />
      )}

      {/* MODAL 3: RECRUITER CHAT DRAWER */}
      <RecruiterChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        messages={messages}
        onSendMessage={(newMsg) => setMessages(prev => [...prev, newMsg])}
        profile={profile}
        activeRecruiterCompany={chatCompany}
      />
    </div>
  );
}
