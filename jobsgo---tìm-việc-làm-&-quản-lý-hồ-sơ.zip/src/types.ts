export type SalaryType = 'range' | 'up_to' | 'from' | 'negotiable';

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo: string;
  companySize: string;
  verifiedCompany: boolean;
  location: string;
  city: string;
  district: string;
  salaryText: string;
  minSalary?: number; // in million VND
  maxSalary?: number; // in million VND
  salaryType: SalaryType;
  level: string; // Thực tập sinh, Nhân viên, Trưởng nhóm, Trưởng phòng, Giám đốc
  experience: string; // Chưa có kinh nghiệm, Dưới 1 năm, 1 - 2 năm, 2 - 3 năm, 3 - 5 năm, Trên 5 năm
  jobType: string; // Toàn thời gian, Bán thời gian, Thực tập, Remote, Hybrid
  industry: string; // CNTT / Phần mềm, Marketing, Kinh doanh, Thiết kế, Tài chính, Nhân sự, v.v.
  tags: string[];
  requiredSkills: string[];
  deadline: string;
  postedAt: string;
  isHot?: boolean;
  isUrgent?: boolean;
  applicantsCount: number;
  viewsCount: number;
  description: string[];
  requirements: string[];
  benefits: string[];
  address: string;
  companyOverview: string;
  contactEmail: string;
}

export interface FilterState {
  keyword: string;
  city: string;
  industry: string;
  salaryRange: string;
  experience: string;
  level: string;
  jobType: string;
  isUrgentOnly: boolean;
  isRemoteOnly: boolean;
  sortBy: 'relevant' | 'newest' | 'salary_high' | 'deadline';
}

export interface WorkExperience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  description: string;
  achievements?: string;
}

export interface Education {
  id: string;
  school: string;
  degree: string;
  major: string;
  startDate: string;
  endDate: string;
  grade: string;
}

export interface Skill {
  id: string;
  name: string;
  level: number; // 1 to 5
  category: 'technical' | 'soft' | 'language';
}

export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  link?: string;
}

export interface Project {
  id: string;
  name: string;
  role: string;
  startDate: string;
  endDate: string;
  link?: string;
  description: string;
  techStack: string[];
}

export interface JobPreference {
  desiredTitle: string;
  desiredLevel: string;
  desiredMinSalary: number; // million VND
  desiredLocations: string[];
  desiredJobTypes: string[];
  desiredIndustries: string[];
}

export interface CandidateProfile {
  id: string;
  fullName: string;
  title: string;
  email: string;
  phone: string;
  birthday: string;
  gender: 'Nam' | 'Nữ' | 'Khác';
  address: string;
  city: string;
  avatar: string;
  bio: string;
  careerObjective: string;
  website?: string;
  github?: string;
  linkedin?: string;
  experiences: WorkExperience[];
  educations: Education[];
  skills: Skill[];
  certificates: Certificate[];
  projects: Project[];
  preferences: JobPreference;
  isLookingForJob: boolean;
  allowRecruitersSearch: boolean;
  emailNotifications: boolean;
  profileStrength: number; // 0 - 100
}

export type ApplicationStatus = 'applied' | 'viewed' | 'interview' | 'offered' | 'rejected';

export interface Application {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  companyLogo: string;
  location: string;
  salaryText: string;
  appliedAt: string;
  status: ApplicationStatus;
  cvType: 'profile' | 'custom';
  cvName: string;
  coverLetter?: string;
  notes?: string;
  interviewDate?: string;
}

export interface RecruiterView {
  id: string;
  companyName: string;
  companyLogo: string;
  viewedAt: string;
  jobTitleSearched: string;
  city: string;
}

export interface ChatMessage {
  id: string;
  sender: 'recruiter' | 'candidate';
  senderName: string;
  avatar: string;
  text: string;
  timestamp: string;
  jobTitle?: string;
}
