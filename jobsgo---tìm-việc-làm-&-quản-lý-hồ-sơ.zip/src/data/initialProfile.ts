import { CandidateProfile, Application, RecruiterView, ChatMessage } from '../types';

export const INITIAL_PROFILE: CandidateProfile = {
  id: 'cand-001',
  fullName: 'Nguyễn Hoàng Minh',
  title: 'Senior Frontend Engineer / Web Architect',
  email: 'hoangminh.dev@gmail.com',
  phone: '0988 765 432',
  birthday: '1996-08-15',
  gender: 'Nam',
  address: 'Số 45 Đường D1, Phường 25, Quận Bình Thạnh',
  city: 'TP. Hồ Chí Minh',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=256&auto=format&fit=crop&q=80',
  bio: 'Lập trình viên Frontend với hơn 5 năm kinh nghiệm chuyên sâu về kiến trúc ứng dụng web hiện đại (React, TypeScript, Next.js, Micro-frontends). Đam mê tối ưu hiệu năng trang web (Core Web Vitals), xây dựng Design System và truyền cảm hứng làm việc cho đồng đội.',
  careerObjective: 'Mục tiêu trở thành Technical Lead / Frontend Architect dẫn dắt các giải pháp quy mô triệu người dùng tại các tập đoàn công nghệ lớn hoặc kỳ lân Đông Nam Á. Tiếp tục hoàn thiện kỹ năng System Design và đóng góp cho cộng đồng mã nguồn mở.',
  website: 'https://hoangminh.dev',
  github: 'https://github.com/hoangminh-tech',
  linkedin: 'https://linkedin.com/in/hoangminh-frontend',
  experiences: [
    {
      id: 'exp-1',
      company: 'Tiki Corporation',
      position: 'Senior Frontend Engineer',
      startDate: '2022-03',
      endDate: 'Hiện tại',
      isCurrent: true,
      description: 'Chịu trách nhiệm kiến trúc và phát triển cổng thanh toán & trang thanh toán (Checkout) của Tiki với lưu lượng xử lý 10,000 requests/phút trong các đợt Mega Sale.',
      achievements: 'Tối ưu chỉ số LCP từ 3.2s xuống 1.1s, giảm 40% dung lượng bundle size qua Code Splitting và lazy loading. Nhận danh hiệu Employee of the Quarter Q3/2023.'
    },
    {
      id: 'exp-2',
      company: 'Sendo.vn / FPT Tech',
      position: 'Frontend Developer',
      startDate: '2019-07',
      endDate: '2022-02',
      isCurrent: false,
      description: 'Phát triển các module Product Catalog, Search & Filter và hệ thống khuyến mãi Voucher trên nền tảng React và Redux Toolkit.',
      achievements: 'Xây dựng thư viện UI component dùng chung giúp giảm 30% thời gian phát triển tính năng mới cho 4 team sản phẩm.'
    }
  ],
  educations: [
    {
      id: 'edu-1',
      school: 'Đại học Bách Khoa TP.HCM (HCMUT)',
      degree: 'Cử nhân Kỹ thuật Phần mềm',
      major: 'Khoa học & Kỹ thuật Máy tính',
      startDate: '2014-09',
      endDate: '2019-06',
      grade: 'Giỏi (GPA: 3.45 / 4.0)'
    }
  ],
  skills: [
    { id: 'sk-1', name: 'React.js & Next.js', level: 5, category: 'technical' },
    { id: 'sk-2', name: 'TypeScript', level: 5, category: 'technical' },
    { id: 'sk-3', name: 'Tailwind CSS & CSS Grid', level: 5, category: 'technical' },
    { id: 'sk-4', name: 'State Management (Zustand/Redux)', level: 5, category: 'technical' },
    { id: 'sk-5', name: 'Web Performance Optimization', level: 4, category: 'technical' },
    { id: 'sk-6', name: 'Node.js & Express REST API', level: 4, category: 'technical' },
    { id: 'sk-7', name: 'Làm việc nhóm & Giao tiếp (Teamwork)', level: 5, category: 'soft' },
    { id: 'sk-8', name: 'Tư duy giải quyết vấn đề (Problem Solving)', level: 5, category: 'soft' },
    { id: 'sk-9', name: 'Tiếng Anh chuyên ngành (TOEIC 875)', level: 4, category: 'language' }
  ],
  certificates: [
    {
      id: 'cert-1',
      name: 'AWS Certified Cloud Practitioner',
      issuer: 'Amazon Web Services',
      issueDate: '2023-11',
      link: 'https://aws.amazon.com/verification'
    },
    {
      id: 'cert-2',
      name: 'Meta Front-End Developer Professional Certificate',
      issuer: 'Coursera & Meta',
      issueDate: '2022-05',
      link: 'https://coursera.org'
    }
  ],
  projects: [
    {
      id: 'proj-1',
      name: 'E-Commerce Micro-Frontend Platform',
      role: 'Lead Frontend Architect',
      startDate: '2023-01',
      endDate: '2023-09',
      link: 'https://github.com/hoangminh-tech/microfrontend-demo',
      description: 'Hệ thống kiến trúc Micro-frontend phân tán cho sàn thương mại điện tử, cho phép các đội ngũ độc lập deploy module thanh toán, giỏ hàng và danh mục.',
      techStack: ['Webpack 5 Module Federation', 'React 18', 'TypeScript', 'Tailwind', 'Docker']
    },
    {
      id: 'proj-2',
      name: 'Real-time Financial Chart Analytics',
      role: 'Fullstack Creator',
      startDate: '2022-08',
      endDate: '2022-12',
      link: 'https://analytics.hoangminh.dev',
      description: 'Bảng theo dõi thị trường tài chính và tiền số thời gian thực với đồ thị nến tương tác tốc độ 60fps.',
      techStack: ['Next.js', 'WebSockets', 'TradingView Lightweight Charts', 'Redis']
    }
  ],
  preferences: {
    desiredTitle: 'Senior Frontend / Tech Lead',
    desiredLevel: 'Trưởng nhóm',
    desiredMinSalary: 35,
    desiredLocations: ['TP. Hồ Chí Minh', 'Toàn quốc (Remote)'],
    desiredJobTypes: ['Toàn thời gian', 'Remote'],
    desiredIndustries: ['CNTT / Phần mềm', 'Tài chính / Ngân hàng']
  },
  isLookingForJob: true,
  allowRecruitersSearch: true,
  emailNotifications: true,
  profileStrength: 92
};

export const INITIAL_APPLICATIONS: Application[] = [
  {
    id: 'app-1',
    jobId: 'job-1',
    jobTitle: 'Senior Frontend Developer (React, TypeScript)',
    company: 'VNG Corporation',
    companyLogo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=128&auto=format&fit=crop&q=80',
    location: 'TP. Hồ Chí Minh',
    salaryText: '30 - 45 triệu',
    appliedAt: '2026-03-01 14:30',
    status: 'interview',
    cvType: 'profile',
    cvName: 'CV_Nguyen_Hoang_Minh_Nextstep.pdf',
    coverLetter: 'Kính gửi ban tuyển dụng VNG Corporation, với hơn 5 năm phát triển web và tối ưu hệ thống thương mại điện tử lớn, tôi rất tự tin có thể đóng góp giá trị cao cho sản phẩm Zalo/ZaloPay.',
    notes: 'Lịch phỏng vấn vòng 1 Kỹ thuật: Thứ Năm 10:00 qua Zoom với anh Tuấn (Tech Lead).',
    interviewDate: '2026-03-06 10:00'
  },
  {
    id: 'app-2',
    jobId: 'job-7',
    jobTitle: 'Fullstack NodeJS / ReactJS Developer (Remote 100%)',
    company: 'Ascenda Loyalty Tech',
    companyLogo: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=128&auto=format&fit=crop&q=80',
    location: 'Toàn quốc (Remote)',
    salaryText: '35 - 55 triệu',
    appliedAt: '2026-03-02 09:15',
    status: 'viewed',
    cvType: 'profile',
    cvName: 'CV_Nguyen_Hoang_Minh_Nextstep.pdf',
    coverLetter: 'Xin chào HR Ascenda, tôi có kinh nghiệm làm việc remote với các đối tác nước ngoài và rất hào hứng với sản phẩm loyalty platform của quý công ty.',
    notes: 'Nhà tuyển dụng đã xem hồ sơ lúc 11:20 hôm qua.'
  }
];

export const INITIAL_RECRUITER_VIEWS: RecruiterView[] = [
  {
    id: 'view-1',
    companyName: 'VNG Corporation',
    companyLogo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=128&auto=format&fit=crop&q=80',
    viewedAt: '2 giờ trước',
    jobTitleSearched: 'Tìm kiếm ứng viên "Senior Frontend Developer"',
    city: 'TP. Hồ Chí Minh'
  },
  {
    id: 'view-2',
    companyName: 'Shopee Việt Nam',
    companyLogo: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=128&auto=format&fit=crop&q=80',
    viewedAt: 'Hôm qua',
    jobTitleSearched: 'Tìm kiếm ứng viên "React, TypeScript, 5 năm KN"',
    city: 'TP. Hồ Chí Minh'
  },
  {
    id: 'view-3',
    companyName: 'FPT Software',
    companyLogo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=128&auto=format&fit=crop&q=80',
    viewedAt: '3 ngày trước',
    jobTitleSearched: 'Tìm kiếm hồ sơ ứng viên khu vực Miền Nam',
    city: 'TP. Hồ Chí Minh'
  }
];

export const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'recruiter',
    senderName: 'Ms. Lan Anh (HR VNG Corp)',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&auto=format&fit=crop&q=80',
    text: 'Chào Minh, hồ sơ của bạn cho vị trí Senior Frontend tại VNG rất ấn tượng. Team mình muốn mời bạn tham gia buổi phỏng vấn kỹ thuật online vào sáng thứ Năm nhé!',
    timestamp: 'Hôm nay lúc 10:15',
    jobTitle: 'Senior Frontend Developer'
  },
  {
    id: 'msg-2',
    sender: 'candidate',
    senderName: 'Nguyễn Hoàng Minh',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&auto=format&fit=crop&q=80',
    text: 'Dạ chào chị Lan Anh, em đã nhận được thư mời và đã chuẩn bị sẵn sàng cho buổi phỏng vấn ạ. Em cảm ơn chị!',
    timestamp: 'Hôm nay lúc 10:20'
  }
];
