import { Job } from '../types';

export const INITIAL_JOBS: Job[] = [
  {
    id: 'job-nextstep-1',
    title: 'Senior Frontend / Fullstack Engineer (React, TypeScript, Node.js)',
    company: 'Công ty Cổ phần Nextstep',
    companyLogo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=128&auto=format&fit=crop&q=80',
    companySize: '100 - 499 nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Quận Cầu Giấy',
    salaryText: '30 - 48 triệu',
    minSalary: 30,
    maxSalary: 48,
    salaryType: 'range',
    level: 'Trưởng nhóm',
    experience: '3 - 5 năm',
    jobType: 'Toàn thời gian',
    industry: 'CNTT / Phần mềm',
    tags: ['Nextstep', 'React', 'TypeScript', 'Node.js', 'Tailwind', 'High Performance'],
    requiredSkills: ['React', 'TypeScript', 'Node.js', 'Tailwind', 'RESTful API'],
    deadline: '2026-05-30',
    postedAt: 'Vừa đăng hôm nay',
    isHot: true,
    isUrgent: true,
    applicantsCount: 12,
    viewsCount: 680,
    description: [
      'Tham gia kiến trúc và phát triển nền tảng công nghệ tuyển dụng & kết nối nhân tài thế hệ mới của Công ty Cổ phần Nextstep.',
      'Thiết kế giao diện người dùng mượt mà, thông minh, tối ưu hóa tương tác tìm kiếm và tự động khớp hồ sơ ứng viên (Smart Profile Matching).',
      'Định hình chuẩn code chất lượng cao, viết unit test, code review và hỗ trợ các kỹ sư trẻ trong team.',
      'Phối hợp với Giám đốc Công nghệ (CTO) và Ban Giám đốc Nextstep để hiện thực hóa các tính năng đột phá.'
    ],
    requirements: [
      'Tối thiểu 3 năm kinh nghiệm lập trình chuyên sâu với React, TypeScript, Tailwind CSS và hệ sinh thái frontend hiện đại.',
      'Có kinh nghiệm làm việc với Node.js / Express / NestJS hoặc RESTful & GraphQL APIs.',
      'Tư duy thiết kế giao diện thông minh (UX/UI-centric), quan tâm đến độ trễ, hiệu năng render và trải nghiệm người dùng.',
      'Tinh thần trách nhiệm cao, chủ động, khát khao đồng hành cùng Nextstep tạo dựng giá trị lớn cho cộng đồng lao động.'
    ],
    benefits: [
      'Mức thu nhập hấp dẫn: 30 - 48 triệu/tháng + Thưởng hiệu quả dự án định kỳ quý/năm.',
      'Làm việc tại trụ sở chính tiện nghi: Ngõ 5, đường Hoàng Quốc Việt, phường Nghĩa Đô, quận Cầu Giấy, Hà Nội.',
      'Đóng bảo hiểm xã hội, y tế đầy đủ trên 100% lương ký kết theo luật lao động.',
      'Trang bị máy tính cấu hình cao (Macbook Pro / Dell XPS), hỗ trợ cơm trưa, teambuilding 2 lần/năm.',
      'Hỗ trợ chế độ linh hoạt (Flexible Hours) & 1 ngày Remote/tuần.'
    ],
    address: 'Ngõ 5, đường Hoàng Quốc Việt, phường Nghĩa Đô, quận Cầu Giấy, Hà Nội',
    companyOverview: 'Công ty Cổ phần Nextstep là doanh nghiệp tiên phong trong lĩnh vực công nghệ nhân sự và giải pháp tuyển dụng thông minh. Với sứ mệnh giúp mọi nhân tài tìm thấy bệ phóng sự nghiệp lý tưởng, Nextstep không ngừng đổi mới sáng tạo.',
    contactEmail: 'chunghr09@gmail.com'
  },
  {
    id: 'job-nextstep-2',
    title: 'Chuyên Viên Tuyển Dụng & Phát Triển Nhân Tài (Talent Acquisition Specialist)',
    company: 'Công ty Cổ phần Nextstep',
    companyLogo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&auto=format&fit=crop&q=80',
    companySize: '100 - 499 nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Quận Cầu Giấy',
    salaryText: '18 - 28 triệu',
    minSalary: 18,
    maxSalary: 28,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '1 - 2 năm',
    jobType: 'Toàn thời gian',
    industry: 'Nhân sự / Tuyển dụng',
    tags: ['Nextstep', 'Headhunter', 'Tuyển dụng', 'Sourcing', 'Phỏng vấn'],
    requiredSkills: ['Tuyển dụng', 'Headhunting', 'Kỹ năng phỏng vấn', 'Giao tiếp'],
    deadline: '2026-05-25',
    postedAt: 'Vừa xong',
    isHot: true,
    isUrgent: true,
    applicantsCount: 8,
    viewsCount: 420,
    description: [
      'Chủ động tìm kiếm, tạo nguồn (sourcing) và tiếp cận ứng viên tiềm năng cho các vị trí công nghệ & kinh doanh tại Công ty Cổ phần Nextstep và đối tác chiến lược.',
      'Thực hiện sàng lọc CV, tổ chức và điều phối các buổi phỏng vấn trực tiếp hoặc online qua Google Meet.',
      'Chăm sóc ứng viên từ khâu tiếp nhận đến khi nhận việc (onboarding), nâng cao trải nghiệm ứng viên (Candidate Experience).',
      'Đại diện Nextstep tham gia các ngày hội việc làm (Job Fairs) và liên kết với các trường đại học lớn tại Hà Nội.'
    ],
    requirements: [
      'Tối thiểu 1 - 2 năm kinh nghiệm trong mảng tuyển dụng nội bộ hoặc Headhunter/Agency.',
      'Kỹ năng giao tiếp xuất sắc, giọng nói truyền cảm, khả năng đàm phán và thuyết phục ứng viên tốt.',
      'Linh hoạt, nhạy bén với xu hướng thị trường lao động và nhân sự công nghệ.',
      'Tác phong chuyên nghiệp, tinh thần đồng đội cao.'
    ],
    benefits: [
      'Lương cứng 18 - 28 triệu/tháng + Thưởng hoa hồng tuyển dụng theo số lượng/chất lượng ứng viên onboard.',
      'Trụ sở làm việc: Ngõ 5, đường Hoàng Quốc Việt, phường Nghĩa Đô, quận Cầu Giấy, Hà Nội.',
      'Được tiếp cận mạng lưới dữ liệu ứng viên chất lượng cao cùng các công cụ AI tuyển dụng của Nextstep.',
      'Môi trường làm việc cởi mở, sáng tạo, cơ hội thăng tiến lên Trưởng nhóm tuyển dụng (TA Lead) sau 6 - 9 tháng.'
    ],
    address: 'Ngõ 5, đường Hoàng Quốc Việt, phường Nghĩa Đô, quận Cầu Giấy, Hà Nội',
    companyOverview: 'Công ty Cổ phần Nextstep là doanh nghiệp tiên phong trong lĩnh vực công nghệ nhân sự và giải pháp tuyển dụng thông minh tại Việt Nam.',
    contactEmail: 'chunghr09@gmail.com'
  },
  {
    id: 'job-1',
    title: 'Senior Frontend Developer (React, TypeScript)',
    company: 'VNG Corporation',
    companyLogo: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'TP. Hồ Chí Minh',
    city: 'TP. Hồ Chí Minh',
    district: 'Quận 7',
    salaryText: '30 - 45 triệu',
    minSalary: 30,
    maxSalary: 45,
    salaryType: 'range',
    level: 'Trưởng nhóm',
    experience: '3 - 5 năm',
    jobType: 'Toàn thời gian',
    industry: 'CNTT / Phần mềm',
    tags: ['React', 'TypeScript', 'Tailwind', 'Next.js', 'Redux Toolkit'],
    requiredSkills: ['React', 'TypeScript', 'HTML/CSS', 'Webpack', 'State Management'],
    deadline: '2026-04-15',
    postedAt: 'Hôm nay',
    isHot: true,
    isUrgent: true,
    applicantsCount: 18,
    viewsCount: 342,
    description: [
      'Tham gia phát triển kiến trúc Frontend cho hệ sinh thái sản phẩm Zalo/ZaloPay với hàng triệu người dùng hoạt động hàng ngày.',
      'Tối ưu hóa hiệu năng render, web vitals, bundle size và nâng cao trải nghiệm người dùng (UX/UI).',
      'Định hình chuẩn code, viết unit test, code review và mentor các bạn Frontend Junior/Middle trong team.',
      'Phối hợp chặt chẽ với Product Owner, Designer và Backend Engineers để triển khai các tính năng mới theo mô hình Agile/Scrum.'
    ],
    requirements: [
      'Tối thiểu 3.5 năm kinh nghiệm làm việc chuyên sâu với ReactJS, TypeScript và hiện đại hóa web app.',
      'Thành thạo quản lý state (Zustand/Redux Toolkit/React Query), xử lý async flow và API caching.',
      'Hiểu sâu về DOM rendering pipeline, Webpack/Vite optimization, SSR/SSG với Next.js.',
      'Tư duy giải quyết vấn đề tốt, trách nhiệm cao, khả năng giao tiếp kỹ thuật và làm việc nhóm hiệu quả.'
    ],
    benefits: [
      'Mức lương cạnh tranh từ 30 - 45 triệu Net + Thưởng tháng 13, 14 tùy theo hiệu quả kinh doanh.',
      'Gói bảo hiểm sức khỏe cao cấp Bảo Việt / VNG Care cho nhân viên và người thân.',
      'Trang bị Macbook Pro M-series đời mới nhất, màn hình 4K.',
      'Cơm trưa miễn phí tại canteen 5 sao, cà phê, snack, trà sữa không giới hạn.',
      'Hỗ trợ 2 ngày làm việc từ xa (Remote Hybrid) mỗi tuần.'
    ],
    address: 'VNG Campus, Đường số 13, Khu chế xuất Tân Thuận, Phường Tân Thuận Đông, Quận 7, TP.HCM',
    companyOverview: 'VNG Corporation là kỳ lân công nghệ đầu tiên của Việt Nam với các sản phẩm quốc dân như Zalo, ZaloPay, Zing MP3, VNGGames.',
    contactEmail: 'recruitment@vng.com.vn'
  },
  {
    id: 'job-2',
    title: 'Trưởng Nhóm Digital Marketing / Growth Lead',
    company: 'Shopee Việt Nam',
    companyLogo: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=128&auto=format&fit=crop&q=80',
    companySize: '500 - 1000 nhân viên',
    verifiedCompany: true,
    location: 'TP. Hồ Chí Minh',
    city: 'TP. Hồ Chí Minh',
    district: 'Quận 1',
    salaryText: '25 - 35 triệu',
    minSalary: 25,
    maxSalary: 35,
    salaryType: 'range',
    level: 'Trưởng nhóm',
    experience: '3 - 5 năm',
    jobType: 'Toàn thời gian',
    industry: 'Marketing / Truyền thông',
    tags: ['Facebook Ads', 'Google Ads', 'TikTok Ads', 'Performance', 'Growth Hacking'],
    requiredSkills: ['Performance Marketing', 'Data Analysis', 'Google Analytics 4', 'Team Management'],
    deadline: '2026-04-20',
    postedAt: '1 ngày trước',
    isHot: true,
    applicantsCount: 29,
    viewsCount: 512,
    description: [
      'Xây dựng chiến lược tăng trưởng người dùng (User Acquisition) và giữ chân (Retention) qua các kênh Paid Media (Meta, Google, TikTok, Affiliates).',
      'Quản lý ngân sách Digital Ads quy mô lớn (từ 500 triệu - 2 tỷ/tháng), liên tục tối ưu CAC, ROAS và LTV.',
      'Phối hợp với Creative Studio để thử nghiệm hàng trăm mẫu ad formats video ngắn/livestream bắt trend.',
      'Đọc hiểu và trực quan hóa số liệu chuyển đổi (funnel analysis) bằng Looker Studio / Power BI.'
    ],
    requirements: [
      'Có từ 3 - 5 năm kinh nghiệm chạy performance ads quy mô lớn trong ngành E-commerce, Fintech hoặc FMCG.',
      'Tư duy số liệu nhạy bén, khả năng đọc hiểu data và ra quyết định dựa trên insight người dùng.',
      'Có kinh nghiệm lead team từ 3 - 6 bạn marketer là một lợi thế lớn.',
      'Tiếng Anh giao tiếp tốt trong môi trường đa quốc gia.'
    ],
    benefits: [
      'Lương cứng 25 - 35 triệu + Thưởng KPI chiến dịch siêu sale (Mega campaigns).',
      'Được đào tạo trực tiếp từ các chuyên gia khu vực Sea Group.',
      'Môi trường trẻ trung, văn phòng hạng A tại trung tâm Quận 1.',
      'Du lịch công ty hàng năm, 15 ngày phép có lương.'
    ],
    address: 'Tòa nhà Saigon Centre, 67 Lê Lợi, Phường Bến Nghé, Quận 1, TP.HCM',
    companyOverview: 'Shopee là nền tảng thương mại điện tử hàng đầu tại Đông Nam Á và Đài Loan.',
    contactEmail: 'talent@shopee.vn'
  },
  {
    id: 'job-3',
    title: 'Kỹ Sư Backend Java / Spring Boot Microservices',
    company: 'FPT Software',
    companyLogo: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Cầu Giấy',
    salaryText: '22 - 38 triệu',
    minSalary: 22,
    maxSalary: 38,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '2 - 3 năm',
    jobType: 'Toàn thời gian',
    industry: 'CNTT / Phần mềm',
    tags: ['Java', 'Spring Boot', 'Kafka', 'Docker', 'PostgreSQL', 'AWS'],
    requiredSkills: ['Java Core', 'Spring Boot', 'Microservices Architecture', 'SQL/NoSQL', 'Git'],
    deadline: '2026-04-18',
    postedAt: 'Hôm nay',
    isHot: true,
    isUrgent: true,
    applicantsCount: 14,
    viewsCount: 280,
    description: [
      'Tham gia dự án chuyển đổi số quy mô lớn cho đối tác ngân hàng và tài chính quốc tế (Nhật Bản, Bắc Mỹ).',
      'Thiết kế và lập trình các dịch vụ Microservices hiệu năng cao sử dụng Spring Boot, Spring Cloud và Apache Kafka.',
      'Tối ưu hóa truy vấn cơ sở dữ liệu PostgreSQL, Redis caching, triển khai hạ tầng CI/CD trên Docker và Kubernetes.'
    ],
    requirements: [
      'Từ 2 năm kinh nghiệm lập trình Java, thành thạo Spring Framework (Spring Boot, Spring Security, Spring Data).',
      'Nắm vững kiến thức về OOP, Design Patterns, RESTful API và cấu trúc dữ liệu thuật toán.',
      'Có hiểu biết về Message Queue (Kafka/RabbitMQ) và dịch vụ đám mây (AWS/GCP/Azure).',
      'Biết tiếng Nhật hoặc tiếng Anh là lợi thế để hưởng thêm phụ cấp ngôn ngữ lên tới 8 triệu/tháng.'
    ],
    benefits: [
      'Thu nhập từ 22 - 38 triệu + Phụ cấp dự án + Thưởng onsite ngắn/dài hạn tại Nhật hoặc Mỹ.',
      'Gói khám sức khỏe FPT Care trị giá 40 triệu/năm.',
      'Lớp học nâng cao ngoại ngữ và chứng chỉ AWS/Java do công ty tài trợ 100%.',
      'Khuôn viên F-Ville xanh mát có sân bóng đá, tennis, bể bơi.'
    ],
    address: 'FPT Tower, Số 10 Phạm Văn Bạch, Dịch Vọng, Cầu Giấy, Hà Nội',
    companyOverview: 'FPT Software là công ty dịch vụ công nghệ thông tin toàn cầu lớn nhất Việt Nam.',
    contactEmail: 'recruitment@fsoft.com.vn'
  },
  {
    id: 'job-4',
    title: 'Chuyên Viên Phân Tích Dữ Liệu Kinh Doanh (BI Analyst)',
    company: 'Techcombank',
    companyLogo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Hoàn Kiếm',
    salaryText: '18 - 28 triệu',
    minSalary: 18,
    maxSalary: 28,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '1 - 2 năm',
    jobType: 'Toàn thời gian',
    industry: 'Tài chính / Ngân hàng',
    tags: ['SQL', 'Power BI', 'Tableau', 'Python', 'Data Analytics'],
    requiredSkills: ['SQL Query', 'Power BI Dashboard', 'Financial Modelling', 'Problem Solving'],
    deadline: '2026-04-25',
    postedAt: '2 ngày trước',
    applicantsCount: 22,
    viewsCount: 410,
    description: [
      'Thu thập, làm sạch và tổng hợp dữ liệu giao dịch ngân hàng từ Data Warehouse của ngân hàng.',
      'Xây dựng các báo cáo quản trị điều hành (Executive Dashboards) bằng Power BI phục vụ Khối Bán lẻ và Khối Khách hàng doanh nghiệp.',
      'Phân tích xu hướng tiêu dùng của khách hàng, dự báo rủi ro tín dụng và đề xuất giải pháp tối ưu doanh thu.'
    ],
    requirements: [
      'Tốt nghiệp Đại học chuyên ngành Tài chính, Kinh tế, Hệ thống thông tin quản lý hoặc Khoa học dữ liệu.',
      'Thành thạo viết câu lệnh SQL phức tạp (Joins, Window Functions, CTEs) và xây dựng data model trong Power BI / DAX.',
      'Khả năng thuyết trình và diễn giải số liệu trực quan cho các bên liên quan phi kỹ thuật.'
    ],
    benefits: [
      'Mức lương hấp dẫn 18 - 28 triệu + Thưởng ngân hàng theo xếp loại kinh doanh từ 3 - 6 tháng lương.',
      'Ưu đãi lãi suất vay mua nhà và ô tô dành riêng cho cán bộ nhân viên Techcombank.',
      'Lộ trình thăng tiến rõ ràng lên Senior BI / Analytics Manager.'
    ],
    address: 'Trụ sở chính Techcombank, Số 6 Quang Trung, Trần Hưng Đạo, Hoàn Kiếm, Hà Nội',
    companyOverview: 'Techcombank là một trong những ngân hàng thương mại cổ phần hàng đầu Việt Nam.',
    contactEmail: 'tuyendung@techcombank.com.vn'
  },
  {
    id: 'job-5',
    title: 'UI/UX Product Designer (Mobile App & Web)',
    company: 'MoMo (M-Service)',
    companyLogo: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'TP. Hồ Chí Minh',
    city: 'TP. Hồ Chí Minh',
    district: 'Quận 7',
    salaryText: '20 - 32 triệu',
    minSalary: 20,
    maxSalary: 32,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '2 - 3 năm',
    jobType: 'Toàn thời gian',
    industry: 'Thiết kế / Đồ họa',
    tags: ['Figma', 'UI/UX', 'Design System', 'Prototyping', 'User Research'],
    requiredSkills: ['Figma Master', 'Mobile App Design', 'Wireframing', 'Design System'],
    deadline: '2026-04-12',
    postedAt: 'Hôm nay',
    isHot: true,
    applicantsCount: 31,
    viewsCount: 490,
    description: [
      'Chịu trách nhiệm thiết kế giao diện và trải nghiệm cho siêu ứng dụng MoMo với hơn 30 triệu người dùng.',
      'Tham gia từ khâu nghiên cứu hành vi người dùng (User Research), phác thảo Wireframe, User Flow đến hoàn thiện High-fidelity Prototype trên Figma.',
      'Đóng góp và bảo trì hệ thống MoMo Design System đồng bộ giữa iOS, Android và Web.',
      'Làm việc cùng Dev để đảm bảo thành phẩm hoàn thiện đúng pixel-perfect so với thiết kế.'
    ],
    requirements: [
      'Có ít nhất 2 năm kinh nghiệm làm UI/UX cho ứng dụng di động (Bắt buộc gửi kèm Portfolio/Behance khi ứng tuyển).',
      'Thành thạo Figma (Auto-layout, Components, Variants, Interactive Components).',
      'Nắm vững nguyên lý thiết kế Human Interface Guidelines (iOS) và Material Design (Android).'
    ],
    benefits: [
      'Thu nhập 20 - 32 triệu + Thưởng performance + Cổ phiếu thưởng ESOP.',
      'Môi trường công nghệ Fintech năng động, được làm việc cùng các Designer kỳ cựu.',
      'Bảo hiểm sức khỏe cao cấp, câu lạc bộ gym, yoga, bóng bàn tại công ty.'
    ],
    address: 'Tòa nhà Phú Mỹ Hưng, Hoàng Văn Thái, Tân Phú, Quận 7, TP.HCM',
    companyOverview: 'MoMo là Siêu ứng dụng thanh toán và tài chính số hàng đầu tại Việt Nam.',
    contactEmail: 'careers@mservice.com.vn'
  },
  {
    id: 'job-6',
    title: 'Nhân Viên Kinh Doanh B2B / Sales IT Solutions',
    company: 'CMC Corporation',
    companyLogo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Cầu Giấy',
    salaryText: '15 - 30 triệu',
    minSalary: 15,
    maxSalary: 30,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '1 - 2 năm',
    jobType: 'Toàn thời gian',
    industry: 'Kinh doanh / Bán hàng',
    tags: ['B2B Sales', 'IT Solutions', 'Cloud', 'Data Center', 'Negotiation'],
    requiredSkills: ['B2B Sales', 'Giao tiếp thuyết phục', 'Thương thảo hợp đồng', 'Quản lý khách hàng'],
    deadline: '2026-04-30',
    postedAt: '3 ngày trước',
    applicantsCount: 16,
    viewsCount: 220,
    description: [
      'Tìm kiếm và tiếp cận các khách hàng doanh nghiệp có nhu cầu về giải pháp CNTT, Hạ tầng Cloud, Bảo mật và Trung tâm dữ liệu.',
      'Tư vấn giải pháp phù hợp với ngân sách của khách hàng, đàm phán hợp đồng thương mại.',
      'Chăm sóc và phát triển mối quan hệ lâu dài với mạng lưới khách hàng Enterprise.'
    ],
    requirements: [
      'Tốt nghiệp Cao đẳng/Đại học khối ngành Kinh tế, Quản trị kinh doanh hoặc CNTT.',
      'Từ 1 năm kinh nghiệm làm Sales B2B, ưu tiên ứng viên đã từng làm trong lĩnh vực phần mềm, thiết bị CNTT hoặc viễn thông.',
      'Kỹ năng giao tiếp xuất sắc, phong thái tự tin, khả năng chịu áp lực doanh số tốt.'
    ],
    benefits: [
      'Lương cứng 12 - 18 triệu + Hoa hồng hoa hồng không giới hạn (Thu nhập trung bình 25 - 35 triệu/tháng).',
      'Được đào tạo bài bản về kiến thức sản phẩm công nghệ cao từ hãng lớn (Microsoft, AWS, Dell, Cisco).',
      'Hỗ trợ công tác phí, điện thoại, tiếp khách đầy đủ.'
    ],
    address: 'CMC Tower, Phố Duy Tân, Dịch Vọng Hậu, Cầu Giấy, Hà Nội',
    companyOverview: 'Tập đoàn Công nghệ CMC là tập đoàn công nghệ thông tin - viễn thông tư nhân hàng đầu tại Việt Nam.',
    contactEmail: 'tuyendung@cmc.com.vn'
  },
  {
    id: 'job-7',
    title: 'Fullstack NodeJS / ReactJS Developer (Remote 100%)',
    company: 'Ascenda Loyalty Tech',
    companyLogo: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=128&auto=format&fit=crop&q=80',
    companySize: '100 - 499 nhân viên',
    verifiedCompany: true,
    location: 'Toàn quốc (Remote)',
    city: 'Toàn quốc',
    district: 'Làm từ xa',
    salaryText: '35 - 55 triệu',
    minSalary: 35,
    maxSalary: 55,
    salaryType: 'range',
    level: 'Trưởng nhóm',
    experience: '3 - 5 năm',
    jobType: 'Remote',
    industry: 'CNTT / Phần mềm',
    tags: ['Node.js', 'React', 'TypeScript', 'GraphQL', 'AWS', 'Remote'],
    requiredSkills: ['Node.js', 'React', 'PostgreSQL', 'English Fluency', 'Clean Code'],
    deadline: '2026-05-10',
    postedAt: 'Hôm nay',
    isHot: true,
    applicantsCount: 42,
    viewsCount: 780,
    description: [
      'Làm việc 100% từ xa cho công ty công nghệ đa quốc gia trụ sở Singapore, cung cấp nền tảng Loyalty cho các hãng hàng không hàng đầu thế giới.',
      'Phát triển API services với Node.js, NestJS, TypeScript và xây dựng Portal quản trị bằng React.',
      'Tích hợp các hệ sinh thái đối tác lớn thông qua REST và GraphQL APIs với độ sẵn sàng cao 99.99%.'
    ],
    requirements: [
      'Ít nhất 3 năm kinh nghiệm lập trình Fullstack với Node.js và React/TypeScript.',
      'Tiếng Anh thành thạo (nghe nói đọc viết) vì làm việc trực tiếp với đồng nghiệp tại Singapore, Châu Âu và Mỹ.',
      'Có tinh thần tự giác cao, khả năng chủ động trong môi trường làm việc từ xa hoàn toàn.'
    ],
    benefits: [
      'Mức lương hấp dẫn từ 35 - 55 triệu (Net) đóng thuế đầy đủ theo luật Việt Nam.',
      'Làm việc tại bất cứ nơi nào bạn muốn (100% Work from Anywhere).',
      'Cấp ngân sách 30 triệu để setup góc làm việc tại nhà (màn hình, bàn ghế công thái học).',
      '20 ngày phép năm và bảo hiểm sức khỏe quốc tế Liberty.'
    ],
    address: 'Làm việc từ xa linh hoạt trên toàn quốc',
    companyOverview: 'Ascenda là công ty công nghệ dịch vụ tài chính & loyalty hàng đầu kết nối các ngân hàng và hãng hàng không lớn nhất toàn cầu.',
    contactEmail: 'talent-sea@ascenda.com'
  },
  {
    id: 'job-8',
    title: 'Chuyên Viên Tuyển Dụng & Phát Triển Nhân Tài (IT Recruiter / TA)',
    company: 'Tiki Corporation',
    companyLogo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&auto=format&fit=crop&q=80',
    companySize: '500 - 1000 nhân viên',
    verifiedCompany: true,
    location: 'TP. Hồ Chí Minh',
    city: 'TP. Hồ Chí Minh',
    district: 'Tân Bình',
    salaryText: '14 - 22 triệu',
    minSalary: 14,
    maxSalary: 22,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '1 - 2 năm',
    jobType: 'Toàn thời gian',
    industry: 'Nhân sự / Hành chính',
    tags: ['IT Recruitment', 'Talent Acquisition', 'Headhunt', 'Sourcing', 'Employer Branding'],
    requiredSkills: ['Sourcing Kỹ sư phần mềm', 'Phỏng vấn hành vi', 'Headhunting', 'Tiếng Anh'],
    deadline: '2026-04-28',
    postedAt: '4 ngày trước',
    applicantsCount: 15,
    viewsCount: 310,
    description: [
      'Chịu trách nhiệm tuyển dụng các vị trí công nghệ cao: Software Engineers, Product Managers, Data Scientists cho Tiki.',
      'Chủ động tìm kiếm (sourcing) ứng viên tiềm năng qua LinkedIn, GitHub, TopDev, JobsGO và mạng lưới cá nhân.',
      'Tổ chức quy trình phỏng vấn chuyên nghiệp, chăm sóc ứng viên từ vòng gửi hồ sơ đến khi Onboarding.',
      'Tham gia các hoạt động xây dựng thương hiệu nhà tuyển dụng (Tech Talk, Hackathon, University Career Fairs).'
    ],
    requirements: [
      'Từ 1.5 năm kinh nghiệm trong lĩnh vực IT Recruitment (Headhunter agency hoặc In-house).',
      'Hiểu biết cơ bản về các thuật ngữ kỹ thuật (Frontend, Backend, DevOps, AI, Mobile).',
      'Kỹ năng giao tiếp khéo léo, thương lượng mức lương và thuyết phục ứng viên tốt.'
    ],
    benefits: [
      'Lương cứng 14 - 22 triệu + Thưởng KPI hoàn thành chỉ tiêu tuyển dụng.',
      'Môi trường trẻ trung, cởi mở, không gian làm việc sáng tạo.',
      'Mã giảm giá mua sắm đặc quyền trên Tiki dành cho nhân viên.'
    ],
    address: 'Tòa nhà Viettel Complex, 285 Cách Mạng Tháng 8, Phường 12, Quận 10, TP.HCM',
    companyOverview: 'Tiki là một trong những nền tảng thương mại điện tử đáng tin cậy nhất Việt Nam.',
    contactEmail: 'talent@tiki.vn'
  },
  {
    id: 'job-9',
    title: 'Thực Tập Sinh Lập Trình Web (Frontend / Backend Fresher)',
    company: 'VinAI / Vingroup',
    companyLogo: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Nam Từ Liêm',
    salaryText: '6 - 10 triệu',
    minSalary: 6,
    maxSalary: 10,
    salaryType: 'range',
    level: 'Thực tập sinh',
    experience: 'Chưa có kinh nghiệm',
    jobType: 'Thực tập',
    industry: 'CNTT / Phần mềm',
    tags: ['Fresher', 'Internship', 'React', 'Python', 'Mentorship'],
    requiredSkills: ['JavaScript/Python cơ bản', 'HTML/CSS', 'Tư duy logic', 'Đam mê học hỏi'],
    deadline: '2026-04-10',
    postedAt: 'Hôm nay',
    isHot: true,
    applicantsCount: 65,
    viewsCount: 920,
    description: [
      'Được đào tạo bài bản 1-1 cùng các chuyên gia nghiên cứu và kỹ sư giàu kinh nghiệm.',
      'Tham gia xây dựng các giao diện web nội bộ và công cụ hỗ trợ gắn nhãn dữ liệu cho các mô hình AI/Xe tự hành.',
      'Cơ hội trở thành nhân viên chính thức sau 3 tháng thực tập nếu đạt kết quả xuất sắc.'
    ],
    requirements: [
      'Sinh viên năm cuối hoặc mới tốt nghiệp chuyên ngành CNTT, Toán tin hoặc Điện tử viễn thông.',
      'Có kiến thức cơ bản vững chắc về lập trình (JS/TS, Python, C++), nắm được OOP và giải thuật.',
      'Có tinh thần ham học hỏi, cầu tiến và có thể làm việc tối thiểu 4 ngày/tuần.'
    ],
    benefits: [
      'Phụ cấp thực tập từ 6 - 10 triệu/tháng + Hỗ trợ ăn trưa tại văn phòng.',
      'Được cấp chứng nhận thực tập xịn từ Viện nghiên cứu VinAI.',
      'Cơ hội ký hợp đồng lao động chính thức với mức lương khởi điểm từ 18 - 25 triệu sau kỳ thực tập.'
    ],
    address: 'Tòa nhà Symphony, Khu đô thị Vinhomes Riverside, Long Biên, Hà Nội',
    companyOverview: 'VinAI là viện nghiên cứu trí tuệ nhân tạo hàng đầu khu vực thuộc tập đoàn Vingroup.',
    contactEmail: 'internship@vinai.io'
  },
  {
    id: 'job-10',
    title: 'Content Creator & Video Editor TikTok / Reels',
    company: 'Coolmate',
    companyLogo: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=128&auto=format&fit=crop&q=80',
    companySize: '100 - 499 nhân viên',
    verifiedCompany: true,
    location: 'Hà Nội',
    city: 'Hà Nội',
    district: 'Thanh Xuân',
    salaryText: '12 - 18 triệu',
    minSalary: 12,
    maxSalary: 18,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: 'Dưới 1 năm',
    jobType: 'Toàn thời gian',
    industry: 'Marketing / Truyền thông',
    tags: ['TikTok', 'CapCut', 'Premiere', 'Content Marketing', 'Gen Z'],
    requiredSkills: ['Lên kịch bản video ngắn', 'Quay dựng CapCut/Premiere', 'Bắt trend mạng xã hội'],
    deadline: '2026-04-19',
    postedAt: '1 ngày trước',
    applicantsCount: 38,
    viewsCount: 540,
    description: [
      'Lên ý tưởng, viết kịch bản và sản xuất video ngắn hàng ngày cho kênh TikTok thương hiệu đạt triệu view.',
      'Trực tiếp quay hoặc phối hợp cùng talent, biên tập video bằng Premiere Pro / CapCut.',
      'Theo dõi các xu hướng nóng trên mạng xã hội để nhanh chóng ứng dụng vào nội dung bán hàng D2C.'
    ],
    requirements: [
      'Yêu thích thời trang, năng động, am hiểu sâu sắc văn hóa mạng xã hội Gen Z.',
      'Thành thạo kỹ năng quay dựng video cơ bản trên điện thoại hoặc máy ảnh.',
      'Đính kèm link tài khoản TikTok hoặc các video bạn đã từng làm khi gửi hồ sơ.'
    ],
    benefits: [
      'Lương cứng 12 - 18 triệu + Thưởng theo lượt view và doanh số affiliate video.',
      'Trải nghiệm miễn phí các sản phẩm thời trang mới nhất của Coolmate.',
      'Môi trường khởi nghiệp cực kỳ trẻ trung và cởi mở.'
    ],
    address: 'Tầng 3-4, Tòa nhà Golden Palm, 21 Lê Văn Lương, Thanh Xuân, Hà Nội',
    companyOverview: 'Coolmate là thương hiệu thời trang nam ứng dụng công nghệ trực tuyến D2C tiên phong tại Việt Nam.',
    contactEmail: 'jobs@coolmate.me'
  },
  {
    id: 'job-11',
    title: 'Kế Toán Tổng Hợp (General Accountant)',
    company: 'Masan Group',
    companyLogo: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'TP. Hồ Chí Minh',
    city: 'TP. Hồ Chí Minh',
    district: 'Quận 1',
    salaryText: '16 - 22 triệu',
    minSalary: 16,
    maxSalary: 22,
    salaryType: 'range',
    level: 'Nhân viên',
    experience: '2 - 3 năm',
    jobType: 'Toàn thời gian',
    industry: 'Tài chính / Ngân hàng',
    tags: ['Kế toán tổng hợp', 'Thuế', 'Báo cáo tài chính', 'SAP', 'ERP'],
    requiredSkills: ['Hạch toán kế toán', 'Lập báo cáo thuế', 'Phần mềm SAP/MISA', 'Luật kế toán'],
    deadline: '2026-05-02',
    postedAt: '5 ngày trước',
    applicantsCount: 19,
    viewsCount: 265,
    description: [
      'Kiểm tra tính hợp lý, hợp lệ của các chứng từ thu chi và hạch toán vào hệ thống phần mềm SAP.',
      'Lập các tờ khai thuế định kỳ (GTGT, TNCN, TNDN) và làm việc với cơ quan kiểm toán độc lập.',
      'Tham gia lập báo cáo tài chính tháng, quý, năm theo chuẩn mực VAS và IFRS.'
    ],
    requirements: [
      'Tốt nghiệp Đại học chuyên ngành Kế toán - Kiểm toán (ĐH Kinh tế, Tài chính).',
      'Từ 2 năm kinh nghiệm làm việc ở vị trí Kế toán tổng hợp, ưu tiên ứng viên biết dùng phần mềm SAP.',
      'Cẩn thận, tỉ mỉ, trung thực và có trách nhiệm cao trong công việc.'
    ],
    benefits: [
      'Lương 16 - 22 triệu + Lương tháng 13 + Thưởng KPI cuối năm.',
      'Chế độ bảo hiểm y tế cao cấp, phụ cấp cơm trưa và điện thoại.',
      'Cơ hội thăng tiến lên Kế toán trưởng chi nhánh.'
    ],
    address: 'Tòa nhà Central Plaza, 17 Lê Duẩn, Bến Nghé, Quận 1, TP.HCM',
    companyOverview: 'Tập đoàn Masan là một trong những tập đoàn kinh tế tư nhân hàng đầu Việt Nam.',
    contactEmail: 'tuyendung@masangroup.com'
  },
  {
    id: 'job-12',
    title: 'Giám Đốc Kinh Doanh Khu Vực Miền Trung (Regional Sales Director)',
    company: 'Tập Đoàn Sun Group',
    companyLogo: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=128&auto=format&fit=crop&q=80',
    companySize: '1000+ nhân viên',
    verifiedCompany: true,
    location: 'Đà Nẵng',
    city: 'Đà Nẵng',
    district: 'Hải Châu',
    salaryText: '50 - 80 triệu',
    minSalary: 50,
    maxSalary: 80,
    salaryType: 'range',
    level: 'Giám đốc',
    experience: 'Trên 5 năm',
    jobType: 'Toàn thời gian',
    industry: 'Kinh doanh / Bán hàng',
    tags: ['Bất động sản nghỉ dưỡng', 'Quản lý cấp cao', 'Chiến lược kinh doanh', 'Đà Nẵng'],
    requiredSkills: ['Lãnh đạo đội ngũ', 'Hoạch định chiến lược', 'Mối quan hệ khách hàng VIP'],
    deadline: '2026-05-15',
    postedAt: '2 ngày trước',
    isHot: true,
    applicantsCount: 9,
    viewsCount: 620,
    description: [
      'Chịu trách nhiệm toàn diện về chỉ tiêu doanh số bất động sản và du lịch nghỉ dưỡng khu vực miền Trung.',
      'Xây dựng, kiện toàn và dẫn dắt đội ngũ hơn 50 nhân sự quản lý và chuyên viên tư vấn cao cấp.',
      'Phát triển mạng lưới đối tác phân phối F1, các quỹ đầu tư và khách hàng cá nhân siêu giàu (UHNWI).'
    ],
    requirements: [
      'Ít nhất 5 năm ở cấp độ Giám đốc kinh doanh trong ngành Bất động sản nghỉ dưỡng hoặc Khách sạn 5 sao.',
      'Năng lực lãnh đạo truyền cảm hứng, tư duy chiến lược thương mại vượt trội.',
      'Sẵn sàng định cư hoặc công tác thường xuyên tại Đà Nẵng và Phú Quốc.'
    ],
    benefits: [
      'Mức lương cứng 50 - 80 triệu + Thưởng hoa hồng dự án cực lớn (Thu nhập trên 1 tỷ/năm).',
      'Được cấp xe đưa đón riêng, chế độ nghỉ dưỡng miễn phí tại chuỗi resort Sun Group toàn quốc.',
      'Chính sách cổ phiếu ESOP và đãi ngộ chuẩn lãnh đạo cấp cao.'
    ],
    address: 'Tòa nhà Sun Group, Bạch Đằng, Quận Hải Châu, TP. Đà Nẵng',
    companyOverview: 'Sun Group là một trong những tập đoàn đầu tư du lịch, nghỉ dưỡng và hạ tầng hàng đầu Việt Nam.',
    contactEmail: 'talent.director@sungroup.com.vn'
  }
];

export const CITIES = [
  'Tất cả địa điểm',
  'Hà Nội',
  'TP. Hồ Chí Minh',
  'Đà Nẵng',
  'Hải Phòng',
  'Cần Thơ',
  'Bình Dương',
  'Đồng Nai',
  'Toàn quốc'
];

export const INDUSTRIES = [
  'Tất cả ngành nghề',
  'CNTT / Phần mềm',
  'Marketing / Truyền thông',
  'Kinh doanh / Bán hàng',
  'Tài chính / Ngân hàng',
  'Thiết kế / Đồ họa',
  'Nhân sự / Hành chính',
  'Kế toán / Kiểm toán',
  'Vận tải / Logistics'
];

export const SALARY_RANGES = [
  'Tất cả mức lương',
  'Dưới 10 triệu',
  '10 - 15 triệu',
  '15 - 25 triệu',
  '25 - 40 triệu',
  'Trên 40 triệu',
  'Thỏa thuận'
];

export const EXPERIENCES = [
  'Tất cả kinh nghiệm',
  'Chưa có kinh nghiệm',
  'Dưới 1 năm',
  '1 - 2 năm',
  '2 - 3 năm',
  '3 - 5 năm',
  'Trên 5 năm'
];

export const LEVELS = [
  'Tất cả cấp bậc',
  'Thực tập sinh',
  'Nhân viên',
  'Trưởng nhóm',
  'Trưởng phòng',
  'Giám đốc'
];

export const JOB_TYPES = [
  'Tất cả hình thức',
  'Toàn thời gian',
  'Bán thời gian',
  'Remote',
  'Thực tập'
];
