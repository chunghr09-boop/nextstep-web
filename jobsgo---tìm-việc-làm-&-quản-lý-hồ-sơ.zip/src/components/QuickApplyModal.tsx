import React, { useState } from 'react';
import { 
  X, 
  Send, 
  FileText, 
  Upload, 
  CheckCircle2, 
  Sparkles, 
  AlertCircle, 
  User, 
  Mail, 
  Phone,
  ShieldCheck
} from 'lucide-react';
import { Job, CandidateProfile, Application } from '../types';

interface QuickApplyModalProps {
  job: Job | null;
  profile: CandidateProfile;
  onClose: () => void;
  onSubmitApplication: (application: Application) => void;
}

export const QuickApplyModal: React.FC<QuickApplyModalProps> = ({
  job,
  profile,
  onClose,
  onSubmitApplication
}) => {
  if (!job) return null;

  const [cvChoice, setCvChoice] = useState<'profile' | 'upload'>('profile');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [coverLetter, setCoverLetter] = useState<string>(
    `Kính gửi Ban Tuyển dụng ${job.company},\n\nTôi rất quan tâm và mong muốn ứng tuyển vào vị trí ${job.title}. Với nền tảng kiến thức và kinh nghiệm thực chiến trong ngành, tôi tin rằng năng lực của mình sẽ đóng góp thiết thực cho mục tiêu phát triển của quý công ty.\n\nRất mong có cơ hội được trao đổi chi tiết hơn trong buổi phỏng vấn.\n\nTrân trọng,\n${profile.fullName}`
  );
  const [notes, setNotes] = useState<string>('');
  const [candidatePhone, setCandidatePhone] = useState(profile.phone);
  const [candidateEmail, setCandidateEmail] = useState(profile.email);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFileName(e.target.files[0].name);
      setCvChoice('upload');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const now = new Date();
      const formattedTime = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;

      const newApp: Application = {
        id: `app-${Date.now()}`,
        jobId: job.id,
        jobTitle: job.title,
        company: job.company,
        companyLogo: job.companyLogo,
        location: job.city,
        salaryText: job.salaryText,
        appliedAt: formattedTime,
        status: 'applied',
        cvType: cvChoice,
        cvName: cvChoice === 'profile' ? `CV_${profile.fullName.replace(/\s+/g, '_')}_Nextstep.pdf` : (uploadedFileName || 'CV_Ung_Vien.pdf'),
        coverLetter: coverLetter,
        notes: notes || 'Đã gửi hồ sơ thành công qua Nextstep.'
      };

      onSubmitApplication(newApp);
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
      <div 
        id="quick-apply-modal-container"
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Ứng tuyển vị trí {job.title}
              </h2>
              <p className="text-xs text-slate-500">{job.company} • {job.city}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Ứng tuyển thành công!</h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto">
              Hồ sơ của bạn đã được chuyển thẳng tới phòng Nhân sự của <strong>{job.company}</strong>. Nhà tuyển dụng sẽ xem hồ sơ và phản hồi cho bạn qua email hoặc tin nhắn Nextstep.
            </p>
            <div className="pt-4 flex justify-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Đóng &amp; Tiếp tục tìm việc
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 text-xs">
            {/* Candidate Quick Contact Verification */}
            <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-blue-600" />
                  Thông tin ứng viên
                </span>
                <span className="text-[11px] text-teal-700 font-semibold">
                  Tự động đồng bộ từ Hồ sơ Nextstep
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Họ và tên</label>
                  <input
                    type="text"
                    disabled
                    value={profile.fullName}
                    className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-lg text-slate-700 font-medium cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Email nhận thông báo</label>
                  <input
                    type="email"
                    required
                    value={candidateEmail}
                    onChange={(e) => setCandidateEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-800 font-medium focus:ring-2 focus:ring-blue-100"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Số điện thoại liên hệ</label>
                  <input
                    type="tel"
                    required
                    value={candidatePhone}
                    onChange={(e) => setCandidatePhone(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-800 font-medium focus:ring-2 focus:ring-blue-100"
                  />
                </div>
              </div>
            </div>

            {/* Choose CV Method */}
            <div className="space-y-2">
              <label className="block font-bold text-slate-800">
                Chọn CV ứng tuyển:
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Choice 1: Online Nextstep Profile CV */}
                <div
                  onClick={() => setCvChoice('profile')}
                  className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                    cvChoice === 'profile'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-900'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="font-bold text-xs">Hồ sơ Nextstep Online</p>
                        <p className="text-[11px] text-slate-500">Độ hoàn thiện {profile.profileStrength}% (Khuyên dùng)</p>
                      </div>
                    </div>
                    <input
                      type="radio"
                      name="cv_choice"
                      checked={cvChoice === 'profile'}
                      onChange={() => setCvChoice('profile')}
                      className="text-blue-600 mt-1 cursor-pointer"
                    />
                  </div>
                  <div className="mt-2 text-[11px] text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md font-medium flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    Tự động tạo mẫu CV chuẩn ATS xuất sắc
                  </div>
                </div>

                {/* Choice 2: Custom PDF Upload */}
                <div
                  onClick={() => setCvChoice('upload')}
                  className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                    cvChoice === 'upload'
                      ? 'border-blue-600 bg-blue-50/40 text-blue-900'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Upload className="w-5 h-5 text-orange-500" />
                      <div>
                        <p className="font-bold text-xs">Tải lên CV từ máy tính</p>
                        <p className="text-[11px] text-slate-500">Hỗ trợ PDF, DOCX tối đa 5MB</p>
                      </div>
                    </div>
                    <input
                      type="radio"
                      name="cv_choice"
                      checked={cvChoice === 'upload'}
                      onChange={() => setCvChoice('upload')}
                      className="text-blue-600 mt-1 cursor-pointer"
                    />
                  </div>
                  <div className="mt-2">
                    <label className="inline-block px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-[11px] font-semibold cursor-pointer">
                      <span>{uploadedFileName ? `Đã chọn: ${uploadedFileName}` : 'Chọn file...'}</span>
                      <input
                        type="file"
                        accept=".pdf,.docx,.doc"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Cover Letter */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-slate-800">
                  Thư giới thiệu (Cover Letter)
                </label>
                <span className="text-[11px] text-slate-400">Tùy chọn</span>
              </div>
              <textarea
                rows={4}
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-slate-800 focus:ring-2 focus:ring-blue-100 focus:border-blue-500 text-xs leading-relaxed"
                placeholder="Viết vài dòng giới thiệu ngắn gửi trực tiếp tới Nhà tuyển dụng..."
              />
            </div>

            {/* Footer Notice */}
            <div className="text-[11px] text-slate-500 flex items-center gap-2 pt-2 border-t border-slate-100">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Nextstep cam kết bảo mật thông tin cá nhân và số điện thoại của bạn.</span>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                {isSubmitting ? 'Đang gửi hồ sơ...' : 'Nộp hồ sơ ngay'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
