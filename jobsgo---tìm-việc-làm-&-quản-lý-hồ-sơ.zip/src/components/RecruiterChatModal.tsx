import React, { useState } from 'react';
import { 
  X, 
  Send, 
  MessageSquare, 
  Building2, 
  CheckCheck, 
  User,
  Sparkles
} from 'lucide-react';
import { ChatMessage, CandidateProfile } from '../types';

interface RecruiterChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onSendMessage: (msg: ChatMessage) => void;
  profile: CandidateProfile;
  activeRecruiterCompany?: string;
}

export const RecruiterChatModal: React.FC<RecruiterChatModalProps> = ({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  profile,
  activeRecruiterCompany
}) => {
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'candidate',
      senderName: profile.fullName,
      avatar: profile.avatar,
      text: inputText.trim(),
      timestamp: 'Vừa xong'
    };

    onSendMessage(newMsg);
    setInputText('');

    // Simulate recruiter auto-reply after 1.5s
    setTimeout(() => {
      const replies = [
        'Cảm ơn bạn đã phản hồi! Phòng Nhân sự đã nhận được thông tin và sẽ gửi link phòng họp qua email cho bạn nhé.',
        'Chào bạn, chúng mình đã xem qua portfolio dự án của bạn và đánh giá rất cao. Chúng mình sẽ liên hệ sớm nhất!',
        'Tuyệt vời! Hẹn gặp bạn trong buổi trao đổi sắp tới nhé.'
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      const recruiterMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'recruiter',
        senderName: activeRecruiterCompany ? `HR ${activeRecruiterCompany}` : 'Ms. Lan Anh (HR VNG Corp)',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&auto=format&fit=crop&q=80',
        text: randomReply,
        timestamp: 'Vừa xong'
      };
      onSendMessage(recruiterMsg);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
      <div 
        id="recruiter-chat-drawer"
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-200"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&auto=format&fit=crop&q=80"
                alt="Recruiter"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-white"></span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {activeRecruiterCompany ? `Tuyển dụng ${activeRecruiterCompany}` : 'Ms. Lan Anh (HR VNG Corp)'}
              </h3>
              <p className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                <span>Đang trực tuyến</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50 text-xs">
          <div className="text-center my-2">
            <span className="px-2.5 py-1 rounded-full bg-slate-200/80 text-[10px] font-semibold text-slate-600">
              Hôm nay
            </span>
          </div>

          {messages.map((msg) => {
            const isMe = msg.sender === 'candidate';
            return (
              <div
                key={msg.id}
                className={`flex items-end gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                {!isMe && (
                  <img
                    src={msg.avatar}
                    alt={msg.senderName}
                    className="w-7 h-7 rounded-full object-cover shrink-0"
                  />
                )}
                <div
                  className={`max-w-[78%] p-3 rounded-2xl space-y-1 shadow-2xs ${
                    isMe
                      ? 'bg-blue-600 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-xs'
                  }`}
                >
                  <p className="text-[11px] leading-relaxed">{msg.text}</p>
                  <div className={`flex items-center justify-end gap-1 text-[9px] ${isMe ? 'text-blue-100' : 'text-slate-400'}`}>
                    <span>{msg.timestamp}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-blue-200" />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Input bar */}
        <form onSubmit={handleSend} className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
          <input
            type="text"
            placeholder="Nhập tin nhắn trao đổi với nhà tuyển dụng..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-100 focus:border-blue-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-xl transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
