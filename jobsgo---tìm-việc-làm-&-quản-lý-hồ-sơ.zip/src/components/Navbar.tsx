import React, { useState } from 'react';
import { 
  Briefcase, 
  User, 
  FileText, 
  Bookmark, 
  Bell, 
  CheckCircle2, 
  Search, 
  Calculator, 
  ChevronDown, 
  Building2, 
  Eye, 
  MessageSquare,
  Sparkles,
  PhoneCall,
  Mail,
  MapPin
} from 'lucide-react';
import { CandidateProfile, RecruiterView, ChatMessage } from '../types';
import { NextstepLogo } from './NextstepLogo';
import { NEXTSTEP_COMPANY_INFO } from '../data/companyInfo';

interface NavbarProps {
  activeTab: 'jobs' | 'profile' | 'applications' | 'saved' | 'salary' | 'recruiter_portal';
  setActiveTab: (tab: 'jobs' | 'profile' | 'applications' | 'saved' | 'salary' | 'recruiter_portal') => void;
  profile: CandidateProfile;
  applicationsCount: number;
  savedCount: number;
  recruiterViews: RecruiterView[];
  messages: ChatMessage[];
  onOpenChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  profile,
  applicationsCount,
  savedCount,
  recruiterViews,
  messages,
  onOpenChat
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const unreadCount = recruiterViews.length + messages.filter(m => m.sender === 'recruiter').length;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
      {/* Top micro bar */}
      <div className="bg-[#0D2B52] text-slate-200 text-xs py-1.5 px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16">
        <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-4">
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-[11px] sm:text-xs">
            <span className="flex items-center gap-1.5 text-teal-300 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              {NEXTSTEP_COMPANY_INFO.companyName}
            </span>
            <span className="hidden md:inline text-slate-400">|</span>
            <span className="hidden lg:flex items-center gap-1 text-slate-300">
              <MapPin className="w-3 h-3 text-emerald-400" />
              <span>{NEXTSTEP_COMPANY_INFO.address}</span>
            </span>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-[11px] sm:text-xs">
            <a
              href={`tel:${NEXTSTEP_COMPANY_INFO.phoneClean}`}
              className="flex items-center gap-1 text-emerald-300 hover:text-emerald-200 font-bold transition-colors cursor-pointer"
              title="Hotline Tuyển Dụng Nextstep"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Hotline: {NEXTSTEP_COMPANY_INFO.phone}</span>
            </a>
            <span className="text-slate-600">|</span>
            <a
              href={`mailto:${NEXTSTEP_COMPANY_INFO.email}`}
              className="hidden sm:flex items-center gap-1 text-teal-300 hover:text-teal-200 transition-colors cursor-pointer"
              title="Gửi CV tới HR Nextstep"
            >
              <Mail className="w-3 h-3" />
              <span>{NEXTSTEP_COMPANY_INFO.email}</span>
            </a>
            <span className="text-slate-600">|</span>
            <button 
              id="nav-recruiter-portal-btn"
              onClick={() => setActiveTab('recruiter_portal')}
              className="flex items-center gap-1 text-teal-300 hover:text-white font-medium transition-colors cursor-pointer"
            >
              <Building2 className="w-3 h-3" />
              <span>Cổng Tuyển Dụng</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 h-18 flex items-center justify-between">
        {/* Logo & Main Nav */}
        <div className="flex items-center gap-8">
          <button 
            id="brand-logo-btn"
            onClick={() => setActiveTab('jobs')} 
            className="flex items-center gap-1 text-left focus:outline-hidden group cursor-pointer hover:opacity-90 transition-opacity"
          >
            <NextstepLogo variant="full" size="md" showCompany={true} />
          </button>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              id="nav-jobs-btn"
              onClick={() => setActiveTab('jobs')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'jobs'
                  ? 'bg-teal-50 text-[#0D2B52] border border-teal-200 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Search className="w-4 h-4 text-[#137E8F]" />
              Tìm việc làm
            </button>

            <button
              id="nav-profile-btn"
              onClick={() => setActiveTab('profile')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-teal-50 text-[#0D2B52] border border-teal-200 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4 text-[#137E8F]" />
              Quản lý hồ sơ &amp; CV
              <span className="ml-1 text-[11px] bg-teal-100 text-[#0D2B52] font-bold px-1.5 py-0.5 rounded-full">
                {profile.profileStrength}%
              </span>
            </button>

            <button
              id="nav-applications-btn"
              onClick={() => setActiveTab('applications')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'applications'
                  ? 'bg-teal-50 text-[#0D2B52] border border-teal-200 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Briefcase className="w-4 h-4 text-[#137E8F]" />
              Đã ứng tuyển
              {applicationsCount > 0 && (
                <span className="ml-1 text-[11px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-full">
                  {applicationsCount}
                </span>
              )}
            </button>

            <button
              id="nav-saved-btn"
              onClick={() => setActiveTab('saved')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'saved'
                  ? 'bg-teal-50 text-[#0D2B52] border border-teal-200 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Bookmark className="w-4 h-4 text-[#137E8F]" />
              Việc đã lưu
              {savedCount > 0 && (
                <span className="ml-1 text-[11px] bg-slate-200 text-slate-700 font-bold px-1.5 py-0.5 rounded-full">
                  {savedCount}
                </span>
              )}
            </button>

            <button
              id="nav-salary-btn"
              onClick={() => setActiveTab('salary')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'salary'
                  ? 'bg-teal-50 text-[#0D2B52] border border-teal-200 font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Calculator className="w-4 h-4 text-[#137E8F]" />
              Tra cứu lương
            </button>
          </nav>
        </div>

        {/* Right Action Icons & User Info */}
        <div className="flex items-center gap-3">
          {/* Direct recruiter chat */}
          <button
            id="nav-chat-btn"
            onClick={onOpenChat}
            className="relative p-2.5 rounded-full text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
            title="Tin nhắn từ Nhà tuyển dụng"
          >
            <MessageSquare className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-orange-500 rounded-full ring-2 ring-white"></span>
          </button>

          {/* Notifications bell */}
          <div className="relative">
            <button
              id="nav-notifications-btn"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2.5 rounded-full text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
              title="Thông báo"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notification popup */}
            {showNotifications && (
              <div 
                id="notifications-popover"
                className="absolute right-0 mt-2 w-84 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 p-4 z-50 animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-blue-600" />
                    <h3 className="text-sm font-bold text-slate-800">Thông báo tuyển dụng</h3>
                  </div>
                  <span className="text-xs text-blue-600 font-medium">Đánh dấu đã đọc</span>
                </div>

                <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto mt-2">
                  {recruiterViews.map((rv) => (
                    <div key={rv.id} className="py-2.5 flex items-start gap-3 hover:bg-slate-50 rounded-lg p-2 transition-colors">
                      <img src={rv.companyLogo} alt={rv.companyName} className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0" />
                      <div className="text-xs space-y-0.5">
                        <p className="text-slate-800 font-semibold">
                          <span className="text-blue-600">{rv.companyName}</span> vừa xem hồ sơ của bạn!
                        </p>
                        <p className="text-slate-500">{rv.jobTitleSearched}</p>
                        <span className="text-[11px] text-slate-400 block pt-0.5 flex items-center gap-1">
                          <Eye className="w-3 h-3 text-slate-400" />
                          {rv.viewedAt} • {rv.city}
                        </span>
                      </div>
                    </div>
                  ))}

                  <div className="py-2.5 flex items-start gap-3 hover:bg-slate-50 rounded-lg p-2 transition-colors">
                    <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div className="text-xs space-y-0.5">
                      <p className="text-slate-800 font-semibold">Gợi ý việc làm phù hợp 95%</p>
                      <p className="text-slate-500">Có 3 công việc Frontend Developer mới tại TP.HCM phù hợp với hồ sơ của bạn.</p>
                      <span className="text-[11px] text-slate-400 block pt-0.5">Hôm nay</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 text-center">
                  <button 
                    onClick={() => { setShowNotifications(false); setActiveTab('profile'); }}
                    className="text-xs text-blue-600 hover:text-blue-700 font-semibold cursor-pointer"
                  >
                    Xem tất cả lượt xem hồ sơ
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Profile Mini Pill */}
          <div className="relative">
            <button
              id="user-profile-menu-btn"
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
            >
              <img 
                src={profile.avatar} 
                alt={profile.fullName} 
                className="w-8 h-8 rounded-full object-cover ring-2 ring-[#137E8F]" 
              />
              <div className="text-left hidden sm:block">
                <p className="text-xs font-bold text-slate-800 leading-tight max-w-[120px] truncate">
                  {profile.fullName}
                </p>
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span className="text-[10px] text-emerald-600 font-medium">Bật tìm việc</span>
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showUserMenu && (
              <div 
                id="user-dropdown-menu"
                className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
              >
                <div className="p-3 bg-gradient-to-br from-slate-50 to-teal-50/60 rounded-xl mb-2 border border-teal-100/50">
                  <p className="text-xs font-bold text-[#0D2B52]">{profile.fullName}</p>
                  <p className="text-[11px] text-slate-500 truncate">{profile.email}</p>
                  <div className="mt-2.5 flex items-center justify-between text-xs">
                    <span className="text-slate-600">Độ mạnh hồ sơ:</span>
                    <span className="font-bold text-[#137E8F]">{profile.profileStrength}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-[#0D2B52] to-[#137E8F] h-full rounded-full transition-all" 
                      style={{ width: `${profile.profileStrength}%` }}
                    ></div>
                  </div>
                </div>

                <div className="space-y-0.5 text-xs">
                  <button
                    onClick={() => { setActiveTab('profile'); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-700 hover:bg-teal-50/60 hover:text-[#0D2B52] font-medium cursor-pointer"
                  >
                    <User className="w-4 h-4 text-[#137E8F]" />
                    Cập nhật hồ sơ &amp; CV online
                  </button>
                  <button
                    onClick={() => { setActiveTab('applications'); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-700 hover:bg-teal-50/60 hover:text-[#0D2B52] font-medium cursor-pointer"
                  >
                    <Briefcase className="w-4 h-4 text-emerald-600" />
                    Việc làm đã ứng tuyển ({applicationsCount})
                  </button>
                  <button
                    onClick={() => { setActiveTab('saved'); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-700 hover:bg-teal-50/60 hover:text-[#0D2B52] font-medium cursor-pointer"
                  >
                    <Bookmark className="w-4 h-4 text-teal-600" />
                    Việc làm đã lưu ({savedCount})
                  </button>
                  <div className="border-t border-slate-100 my-1"></div>
                  <button
                    onClick={() => { setActiveTab('recruiter_portal'); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-slate-700 hover:bg-slate-100 font-medium cursor-pointer"
                  >
                    <Building2 className="w-4 h-4 text-amber-500" />
                    Cổng Tuyển Dụng Nextstep
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile nav pills bar */}
      <div className="md:hidden flex items-center overflow-x-auto py-2 px-4 border-t border-slate-100 gap-2 no-scrollbar">
        <button
          onClick={() => setActiveTab('jobs')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${
            activeTab === 'jobs' ? 'bg-[#0D2B52] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Tìm việc làm
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${
            activeTab === 'profile' ? 'bg-[#0D2B52] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Quản lý hồ sơ
        </button>
        <button
          onClick={() => setActiveTab('applications')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${
            activeTab === 'applications' ? 'bg-[#0D2B52] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Đã ứng tuyển ({applicationsCount})
        </button>
        <button
          onClick={() => setActiveTab('saved')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${
            activeTab === 'saved' ? 'bg-[#0D2B52] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Việc đã lưu ({savedCount})
        </button>
        <button
          onClick={() => setActiveTab('salary')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap ${
            activeTab === 'salary' ? 'bg-[#0D2B52] text-white' : 'bg-slate-100 text-slate-700'
          }`}
        >
          Tra cứu lương
        </button>
      </div>
    </header>
  );
};
