import React, { useState } from 'react';
import { 
  Building2, 
  Plus, 
  Users, 
  FileText, 
  CheckCircle2, 
  DollarSign, 
  MapPin, 
  Eye, 
  Send,
  Briefcase
} from 'lucide-react';
import { Job, CandidateProfile, Application } from '../types';
import { CITIES, INDUSTRIES } from '../data/mockJobs';

interface RecruiterPortalProps {
  onPostNewJob: (newJob: Job) => void;
  candidateProfile: CandidateProfile;
  applications: Application[];
  onBackToCandidateMode: () => void;
}

export const RecruiterPortal: React.FC<RecruiterPortalProps> = ({
  onPostNewJob,
  candidateProfile,
  applications,
  onBackToCandidateMode
}) => {
  const [activeTab, setActiveTab] = useState<'post' | 'candidates'>('post');
  const [isSuccess, setIsSuccess] = useState(false);

  // Form fields
  const [jobTitle, setJobTitle] = useState('');
  const [companyName, setCompanyName] = useState('Công ty Cổ phần Công nghệ NextGen');
  const [city, setCity] = useState('TP. Hồ Chí Minh');
  const [industry, setIndustry] = useState('CNTT / Phần mềm');
  const [salaryText, setSalaryText] = useState('25 - 40 triệu');
  const [experience, setExperience] = useState('2 - 3 năm');
  const [level, setLevel] = useState('Nhân viên');
  const [jobType, setJobType] = useState('Toàn thời gian');
  const [description, setDescription] = useState('Phát triển các tính năng web application cho hệ thống khách hàng doanh nghiệp...');
  const [requirements, setRequirements] = useState('Tối thiểu 2 năm kinh nghiệm React, TypeScript, khả năng giao tiếp và làm việc nhóm tốt...');
  const [skills, setSkills] = useState('React, TypeScript, CSS, Git');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobTitle) return;

    const newJob: Job = {
      id: `job-custom-${Date.now()}`,
      title: jobTitle,
      company: companyName,
      companyLogo: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=128&auto=format&fit=crop&q=80',
      companySize: '100 - 499 nhân viên',
      verifiedCompany: true,
      location: city,
      city: city,
      district: 'Quận 1',
      salaryText: salaryText,
      minSalary: 25,
      maxSalary: 40,
      salaryType: 'range',
      level: level,
      experience: experience,
      jobType: jobType,
      industry: industry,
      tags: skills.split(',').map(s => s.trim()).filter(Boolean),
      requiredSkills: skills.split(',').map(s => s.trim()).filter(Boolean),
      deadline: '2026-05-30',
      postedAt: 'Vừa xong',
      isHot: true,
      applicantsCount: 0,
      viewsCount: 1,
      description: description.split('\n').filter(Boolean),
      requirements: requirements.split('\n').filter(Boolean),
      benefits: [
        'Lương thưởng cạnh tranh theo năng lực',
        'Bảo hiểm đầy đủ theo quy định nhà nước',
        'Môi trường trẻ trung năng động'
      ],
      address: `Văn phòng tại ${city}`,
      companyOverview: 'Doanh nghiệp công nghệ tiên phong cung cấp giải pháp chuyển đổi số.',
      contactEmail: 'hr@nextgen-tech.vn'
    };

    onPostNewJob(newJob);
    setIsSuccess(true);
    setTimeout(() => setIsSuccess(false), 4000);
    setJobTitle('');
  };

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-8 space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0D2B52] text-white rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-400 text-[#0D2B52] text-xs font-bold uppercase mb-2">
            <Building2 className="w-3.5 h-3.5" />
            Nextstep Recruiter Portal
          </div>
          <h1 className="text-xl sm:text-2xl font-black">Cổng Tuyển Dụng &amp; Đăng Tin Doanh Nghiệp</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
            Tiếp cận hơn 3 triệu hồ sơ ứng viên chất lượng cao trên toàn quốc
          </p>
        </div>

        <button
          onClick={onBackToCandidateMode}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer self-start sm:self-auto"
        >
          Quay lại chế độ Ứng viên
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-3 border-b border-slate-200 pb-3">
        <button
          onClick={() => setActiveTab('post')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'post'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          Đăng tin tuyển dụng mới
        </button>
        <button
          onClick={() => setActiveTab('candidates')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'candidates'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          Duyệt hồ sơ ứng viên ({applications.length})
        </button>
      </div>

      {activeTab === 'post' ? (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          {isSuccess && (
            <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>Đăng tin tuyển dụng thành công! Tin đã xuất hiện ngay trên trang tìm việc làm Nextstep.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <h2 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-2">
              Thông tin vị trí tuyển dụng
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Tiêu đề tin tuyển dụng *</label>
                <input
                  type="text"
                  required
                  placeholder="VD: Senior React Developer (Lương tới 45 triệu)"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900 font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tên công ty *</label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tỉnh / Thành phố *</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                >
                  {CITIES.filter(c => c !== 'Tất cả địa điểm').map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Ngành nghề *</label>
                <select
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                >
                  {INDUSTRIES.filter(i => i !== 'Tất cả ngành nghề').map(i => (
                    <option key={i} value={i}>{i}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Mức lương hiển thị *</label>
                <input
                  type="text"
                  required
                  placeholder="VD: 25 - 40 triệu"
                  value={salaryText}
                  onChange={(e) => setSalaryText(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900 font-bold text-orange-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Yêu cầu kinh nghiệm</label>
                <select
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                >
                  <option value="Chưa có kinh nghiệm">Chưa có kinh nghiệm</option>
                  <option value="Dưới 1 năm">Dưới 1 năm</option>
                  <option value="1 - 2 năm">1 - 2 năm</option>
                  <option value="2 - 3 năm">2 - 3 năm</option>
                  <option value="3 - 5 năm">3 - 5 năm</option>
                  <option value="Trên 5 năm">Trên 5 năm</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cấp bậc</label>
                <select
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                >
                  <option value="Thực tập sinh">Thực tập sinh</option>
                  <option value="Nhân viên">Nhân viên</option>
                  <option value="Trưởng nhóm">Trưởng nhóm</option>
                  <option value="Trưởng phòng">Trưởng phòng</option>
                  <option value="Giám đốc">Giám đốc</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Kỹ năng yêu cầu (phân cách bằng dấu phẩy)</label>
                <input
                  type="text"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  placeholder="React, TypeScript, Next.js..."
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Mô tả công việc</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-3 border border-slate-200 rounded-xl text-slate-900 leading-relaxed"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Yêu cầu ứng viên</label>
                <textarea
                  rows={3}
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  className="w-full p-3 border border-slate-200 rounded-xl text-slate-900 leading-relaxed"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/20 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                Đăng tin ngay
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Candidates View */
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">
              Danh sách ứng viên đã nộp hồ sơ vào các tin của bạn
            </h2>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              {applications.length} hồ sơ
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {applications.map((app) => (
              <div key={app.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src={candidateProfile.avatar}
                    alt={candidateProfile.fullName}
                    className="w-14 h-14 rounded-full object-cover ring-2 ring-blue-500 shrink-0"
                  />
                  <div className="text-xs space-y-0.5">
                    <h3 className="text-sm font-bold text-slate-900">{candidateProfile.fullName}</h3>
                    <p className="text-blue-700 font-semibold">{app.jobTitle}</p>
                    <p className="text-slate-500">Nộp qua: {app.cvName} • Điểm hồ sơ: <strong>{candidateProfile.profileStrength}%</strong></p>
                    <span className="text-[11px] text-slate-400">Ứng tuyển lúc: {app.appliedAt}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => alert(`Đã gửi thông báo hẹn phỏng vấn tới ứng viên ${candidateProfile.fullName}!`)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Mời phỏng vấn
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
