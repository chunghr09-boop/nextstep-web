import React, { useState } from 'react';
import { 
  Calculator, 
  DollarSign, 
  TrendingUp, 
  Building2, 
  PieChart, 
  ShieldCheck, 
  CheckCircle2,
  HelpCircle,
  Briefcase
} from 'lucide-react';

export const SalaryCalculatorView: React.FC = () => {
  // Tool 1: Gross to Net
  const [grossSalary, setGrossSalary] = useState<number>(30); // million VND
  const [dependents, setDependents] = useState<number>(0);
  const [insuranceSalary, setInsuranceSalary] = useState<number>(30); // on full salary

  // Tool 2: Salary Benchmark
  const [selectedRole, setSelectedRole] = useState<string>('Frontend Developer');
  const [selectedExp, setSelectedExp] = useState<string>('3 - 5 năm');
  const [selectedCity, setSelectedCity] = useState<string>('TP. Hồ Chí Minh');

  // Benchmark data map
  const BENCHMARKS: Record<string, Record<string, { min: number; avg: number; max: number }>> = {
    'Frontend Developer': {
      'Dưới 1 năm': { min: 8, avg: 12, max: 15 },
      '1 - 2 năm': { min: 14, avg: 18, max: 24 },
      '2 - 3 năm': { min: 20, avg: 26, max: 32 },
      '3 - 5 năm': { min: 28, avg: 36, max: 48 },
      'Trên 5 năm': { min: 45, avg: 58, max: 80 }
    },
    'Backend Developer': {
      'Dưới 1 năm': { min: 9, avg: 13, max: 16 },
      '1 - 2 năm': { min: 15, avg: 20, max: 26 },
      '2 - 3 năm': { min: 22, avg: 28, max: 35 },
      '3 - 5 năm': { min: 30, avg: 40, max: 55 },
      'Trên 5 năm': { min: 50, avg: 65, max: 90 }
    },
    'Digital Marketing': {
      'Dưới 1 năm': { min: 7, avg: 10, max: 13 },
      '1 - 2 năm': { min: 12, avg: 16, max: 22 },
      '2 - 3 năm': { min: 18, avg: 24, max: 30 },
      '3 - 5 năm': { min: 25, avg: 35, max: 45 },
      'Trên 5 năm': { min: 40, avg: 50, max: 70 }
    },
    'UI/UX Designer': {
      'Dưới 1 năm': { min: 8, avg: 11, max: 14 },
      '1 - 2 năm': { min: 13, avg: 17, max: 23 },
      '2 - 3 năm': { min: 19, avg: 25, max: 32 },
      '3 - 5 năm': { min: 26, avg: 34, max: 45 },
      'Trên 5 năm': { min: 40, avg: 52, max: 68 }
    },
    'Kinh doanh / Sales B2B': {
      'Dưới 1 năm': { min: 8, avg: 14, max: 20 },
      '1 - 2 năm': { min: 15, avg: 22, max: 30 },
      '2 - 3 năm': { min: 20, avg: 30, max: 45 },
      '3 - 5 năm': { min: 30, avg: 45, max: 65 },
      'Trên 5 năm': { min: 45, avg: 70, max: 120 }
    }
  };

  // Vietnamese statutory calculation
  // BHXH 8%, BHYT 1.5%, BHTN 1% -> Total 10.5%
  // Cap base salary for BHXH/BHYT: 20 * 2,340,000 = 46.8 million VND
  const cappedInsuranceSalary = Math.min(grossSalary, 46.8);
  const socialInsurance = cappedInsuranceSalary * 0.08;
  const healthInsurance = cappedInsuranceSalary * 0.015;
  const unemploymentInsurance = Math.min(grossSalary, 99.2) * 0.01;
  const totalInsurance = socialInsurance + healthInsurance + unemploymentInsurance;

  // Personal income tax (Thuế TNCN)
  const personalDeduction = 11; // 11 million
  const dependentDeduction = dependents * 4.4; // 4.4 million per dependent
  const taxableIncome = Math.max(0, grossSalary - totalInsurance - personalDeduction - dependentDeduction);

  let personalTax = 0;
  if (taxableIncome > 0) {
    if (taxableIncome <= 5) personalTax = taxableIncome * 0.05;
    else if (taxableIncome <= 10) personalTax = 5 * 0.05 + (taxableIncome - 5) * 0.1;
    else if (taxableIncome <= 18) personalTax = 5 * 0.05 + 5 * 0.1 + (taxableIncome - 10) * 0.15;
    else if (taxableIncome <= 32) personalTax = 5 * 0.05 + 5 * 0.1 + 8 * 0.15 + (taxableIncome - 18) * 0.2;
    else if (taxableIncome <= 52) personalTax = 5 * 0.05 + 5 * 0.1 + 8 * 0.15 + 14 * 0.2 + (taxableIncome - 32) * 0.25;
    else personalTax = 5 * 0.05 + 5 * 0.1 + 8 * 0.15 + 14 * 0.2 + 20 * 0.25 + (taxableIncome - 52) * 0.3;
  }

  const netSalary = grossSalary - totalInsurance - personalTax;

  const currentBenchmark = BENCHMARKS[selectedRole]?.[selectedExp] || { min: 20, avg: 30, max: 40 };

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-8 space-y-8">
      {/* Title */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <h1 className="text-xl sm:text-2xl font-black text-[#0D2B52] flex items-center gap-2">
          <Calculator className="w-6 h-6 text-[#137E8F]" />
          Công Cụ Tra Cứu Lương &amp; Tính Lương Gross - Net Nextstep
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Dữ liệu thống kê dựa trên hơn 100.000 việc làm đã đăng tuyển và quy định pháp luật lao động hiện hành
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Gross to Net Calculator */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              <h2 className="text-base font-bold text-slate-900">Tính Lương Gross sang Net</h2>
            </div>
            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
              Chuẩn Luật Thuế 2026
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Thu nhập Gross (Triệu VNĐ/tháng)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="3"
                  max="500"
                  value={grossSalary}
                  onChange={(e) => setGrossSalary(Math.max(1, Number(e.target.value)))}
                  className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-extrabold text-sm focus:bg-white focus:ring-2 focus:ring-blue-100"
                />
                <span className="absolute left-3 top-3 text-slate-400 font-bold">₫</span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Số người phụ thuộc (giảm trừ 4.4tr/người)
              </label>
              <input
                type="number"
                min="0"
                max="10"
                value={dependents}
                onChange={(e) => setDependents(Math.max(0, Number(e.target.value)))}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-semibold focus:bg-white focus:ring-2 focus:ring-blue-100"
              />
            </div>
          </div>

          {/* Result Card */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-50/40 border border-emerald-200 space-y-3">
            <div className="flex items-baseline justify-between">
              <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
                Lương thực nhận (Net):
              </span>
              <div className="text-right">
                <span className="text-2xl sm:text-3xl font-black text-emerald-700">
                  {netSalary.toFixed(2)}
                </span>
                <span className="text-xs font-bold text-emerald-800 ml-1">Triệu VNĐ</span>
              </div>
            </div>

            <div className="border-t border-emerald-200/80 pt-3 space-y-1.5 text-xs text-slate-700">
              <div className="flex justify-between">
                <span>Lương Gross:</span>
                <strong className="font-semibold">{grossSalary.toFixed(2)} triệu</strong>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>- Bảo hiểm bắt buộc (10.5%):</span>
                <span>-{totalInsurance.toFixed(2)} triệu</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>- Thuế thu nhập cá nhân (TNCN):</span>
                <span>-{personalTax.toFixed(2)} triệu</span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1">
            <p className="font-semibold text-slate-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Chi tiết các khoản bảo hiểm bắt buộc theo luật:
            </p>
            <p>• Bảo hiểm xã hội: 8% ({socialInsurance.toFixed(2)} triệu)</p>
            <p>• Bảo hiểm y tế: 1.5% ({healthInsurance.toFixed(2)} triệu)</p>
            <p>• Bảo hiểm thất nghiệp: 1% ({unemploymentInsurance.toFixed(2)} triệu)</p>
          </div>
        </div>

        {/* Right: Market Benchmark */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h2 className="text-base font-bold text-slate-900">Tra Cứu Lương Thị Trường</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Vị trí công việc</label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold"
              >
                {Object.keys(BENCHMARKS).map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Số năm kinh nghiệm</label>
              <select
                value={selectedExp}
                onChange={(e) => setSelectedExp(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold"
              >
                {['Dưới 1 năm', '1 - 2 năm', '2 - 3 năm', '3 - 5 năm', 'Trên 5 năm'].map(exp => (
                  <option key={exp} value={exp}>{exp}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Địa điểm làm việc</label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-semibold"
              >
                <option value="TP. Hồ Chí Minh">TP. Hồ Chí Minh</option>
                <option value="Hà Nội">Hà Nội</option>
                <option value="Đà Nẵng">Đà Nẵng</option>
              </select>
            </div>
          </div>

          {/* Benchmark display */}
          <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 space-y-3">
            <div className="text-center">
              <span className="text-[11px] font-bold text-blue-900 uppercase">Mức lương phổ biến trung bình</span>
              <p className="text-2xl font-black text-blue-700 mt-1">
                {currentBenchmark.avg} Triệu VNĐ
              </p>
              <span className="text-[11px] text-slate-500">Mỗi tháng (Gross)</span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-blue-200/70 text-center text-xs">
              <div className="bg-white p-2.5 rounded-lg border border-blue-100">
                <span className="text-[10px] text-slate-500 font-medium">Thấp nhất (P25)</span>
                <p className="font-extrabold text-slate-800">{currentBenchmark.min} triệu</p>
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-blue-100">
                <span className="text-[10px] text-slate-500 font-medium">Cao nhất (P75+)</span>
                <p className="font-extrabold text-orange-600">{currentBenchmark.max} triệu</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
